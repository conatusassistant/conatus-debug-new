import { createClient } from "@supabase/supabase-js"
import type { Automation, ConnectedApp, User } from "./api-types"

// Initialize Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// User functions
export async function getCurrentUser() {
  const {
    data: { user },
  } = await supabase.auth.getUser()
  return user
}

export async function getUserProfile(userId: string): Promise<User | null> {
  const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single()

  if (error) {
    console.error("Error fetching user profile:", error)
    return null
  }

  return data as User
}

// Automation functions
export async function getAutomations(userId: string): Promise<Automation[]> {
  const { data, error } = await supabase
    .from("automations")
    .select("*")
    .eq("userId", userId)
    .order("createdAt", { ascending: false })

  if (error) {
    console.error("Error fetching automations:", error)
    return []
  }

  return data as Automation[]
}

export async function createAutomation(
  automation: Omit<Automation, "id" | "createdAt" | "updatedAt">,
): Promise<Automation | null> {
  const { data, error } = await supabase.from("automations").insert([automation]).select().single()

  if (error) {
    console.error("Error creating automation:", error)
    return null
  }

  return data as Automation
}

export async function updateAutomation(id: string, updates: Partial<Automation>): Promise<Automation | null> {
  const { data, error } = await supabase.from("automations").update(updates).eq("id", id).select().single()

  if (error) {
    console.error("Error updating automation:", error)
    return null
  }

  return data as Automation
}

export async function deleteAutomation(id: string): Promise<boolean> {
  const { error } = await supabase.from("automations").delete().eq("id", id)

  if (error) {
    console.error("Error deleting automation:", error)
    return false
  }

  return true
}

// Connected Apps functions
export async function getConnectedApps(userId: string): Promise<ConnectedApp[]> {
  const { data, error } = await supabase.from("connected_apps").select("*").eq("userId", userId)

  if (error) {
    console.error("Error fetching connected apps:", error)
    return []
  }

  return data as ConnectedApp[]
}

export async function updateConnectedApp(id: string, updates: Partial<ConnectedApp>): Promise<ConnectedApp | null> {
  const { data, error } = await supabase.from("connected_apps").update(updates).eq("id", id).select().single()

  if (error) {
    console.error("Error updating connected app:", error)
    return null
  }

  return data as ConnectedApp
}

