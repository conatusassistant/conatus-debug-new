export interface User {
  id: string
  email: string
  username: string
  createdAt: string
  updatedAt: string
}

export interface Automation {
  id: string
  name: string
  description: string
  icon: string
  isEnabled: boolean
  userId: string
  createdAt: string
  updatedAt: string
  lastRun?: string
  triggerType: "schedule" | "event" | "manual"
  config: Record<string, any>
}

export interface ConnectedApp {
  id: string
  name: string
  icon: string
  isConnected: boolean
  userId: string
  apiKey?: string
  permissions: string[]
  lastSynced?: string
  createdAt: string
  updatedAt: string
}

export interface AutomationRun {
  id: string
  automationId: string
  status: "success" | "failed" | "running"
  startedAt: string
  completedAt?: string
  logs: string[]
  result?: Record<string, any>
}

