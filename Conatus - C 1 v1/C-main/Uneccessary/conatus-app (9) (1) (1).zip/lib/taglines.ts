export const taglines = [
  "Book me an Uber home at 6 PM.",
  "Text Mom goodnight at 8 PM tonight.",
  "Order my usual McDonald's meal for pickup now.",
  "Tell me the fastest route to work and text my boss.",
  "Schedule a Zoom meeting for 10 AM with Ben.",
  "Mute my notifications from 11 AM to 1 PM.",
  "Remind me to drink water every two hours.",
  "Schedule my email to send at 8 AM.",
  "Schedule a WhatsApp message to John for tomorrow.",
  "Play my Spotify workout playlist at the gym.",
  "Tell me when flights to Paris are cheapest.",
  "Alert me when my favorite YouTuber uploads.",
  "Show me trending info → X, news, Reddit.",
  "Post my LinkedIn update during peak engagement hours.",
  "Schedule a Facebook event reminder for my followers.",
  "Reply to my Instagram DMs.",
]

