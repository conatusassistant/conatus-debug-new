"use client"

import { useState, useEffect, useRef } from "react"

export function useTypewriterEffect(text: string, delay = 30, pauseDelay = 2000) {
  const [displayText, setDisplayText] = useState("")
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const pauseTimerRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    // Clear any existing timers
    if (timerRef.current) clearInterval(timerRef.current)
    if (pauseTimerRef.current) clearTimeout(pauseTimerRef.current)

    let i = 0

    // Type characters one by one with better performance
    timerRef.current = setInterval(() => {
      if (i < text.length) {
        setDisplayText((prev) => prev + text.charAt(i))
        i++
      } else {
        if (timerRef.current) clearInterval(timerRef.current)

        // Reset after pause
        pauseTimerRef.current = setTimeout(() => {
          setDisplayText("")
        }, pauseDelay)
      }
    }, delay)

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
      if (pauseTimerRef.current) clearTimeout(pauseTimerRef.current)
    }
  }, [text, delay, pauseDelay])

  return displayText
}

