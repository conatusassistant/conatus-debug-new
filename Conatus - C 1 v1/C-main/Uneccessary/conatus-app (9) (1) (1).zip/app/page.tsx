"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { DashboardView } from "@/components/dashboard-view"
import { LibraryView } from "@/components/library-view"
import { SocialView } from "@/components/social-view"
import { BottomNavigation } from "@/components/bottom-navigation"
import { ConatusHeader } from "@/components/conatus-header"
import { taglines } from "@/lib/taglines"

const pageVariants = {
  initial: { opacity: 0, y: 20 },
  in: { opacity: 1, y: 0 },
  out: { opacity: 0, y: -20 },
}

const pageTransition = {
  type: "tween",
  ease: "anticipate",
  duration: 0.3,
}

export default function Home() {
  const [activeTab, setActiveTab] = useState("home")
  const [currentTagline, setCurrentTagline] = useState(taglines[0])
  const [taglineIndex, setTaglineIndex] = useState(0)

  useEffect(() => {
    const intervalId = setInterval(() => {
      setTaglineIndex((prevIndex) => (prevIndex + 1) % taglines.length)
    }, 3000)

    return () => clearInterval(intervalId)
  }, [])

  useEffect(() => {
    setCurrentTagline(taglines[taglineIndex])
  }, [taglineIndex])

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen flex flex-col"
    >
      <ConatusHeader />
      <main className="flex-grow flex items-center justify-center overflow-hidden">
        <AnimatePresence mode="wait">
          {activeTab === "home" && (
            <motion.div
              key="home"
              initial="initial"
              animate="in"
              exit="out"
              variants={pageVariants}
              transition={pageTransition}
              className="w-full h-full flex items-center justify-center"
            >
              <DashboardView currentTagline={currentTagline} />
            </motion.div>
          )}
          {activeTab === "library" && (
            <motion.div
              key="library"
              initial="initial"
              animate="in"
              exit="out"
              variants={pageVariants}
              transition={pageTransition}
              className="w-full h-full"
            >
              <LibraryView />
            </motion.div>
          )}
          {activeTab === "social" && (
            <motion.div
              key="social"
              initial="initial"
              animate="in"
              exit="out"
              variants={pageVariants}
              transition={pageTransition}
              className="w-full h-full"
            >
              <SocialView />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
      <BottomNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
    </motion.div>
  )
}

