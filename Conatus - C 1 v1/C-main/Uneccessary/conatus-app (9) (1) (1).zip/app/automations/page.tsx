import { Layout } from "@/components/layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"

export default function AutomationsPage() {
  return (
    <Layout>
      <Tabs defaultValue="personal" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="personal">Personal</TabsTrigger>
          <TabsTrigger value="home">Home Automations</TabsTrigger>
          <TabsTrigger value="community">Community</TabsTrigger>
        </TabsList>

        <TabsContent value="personal" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Morning Routine</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-2">Arrange transportation, review calendar, order coffee</p>
              <div className="flex items-center space-x-2">
                <Switch id="morning-routine" />
                <label htmlFor="morning-routine">Enable</label>
              </div>
            </CardContent>
          </Card>

          {/* Add more personal automations here */}
        </TabsContent>

        <TabsContent value="home" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Auto-Schedule Coffee Runs</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-2">Schedule coffee delivery every morning at 8 AM</p>
              <Button variant="outline">Add to Personal</Button>
            </CardContent>
          </Card>

          {/* Add more home automations here */}
        </TabsContent>

        <TabsContent value="community" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Workout Reminder</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-2">Daily reminder to exercise based on your calendar</p>
              <Button variant="outline">Use This</Button>
            </CardContent>
          </Card>

          {/* Add more community automations here */}
        </TabsContent>
      </Tabs>
    </Layout>
  )
}

