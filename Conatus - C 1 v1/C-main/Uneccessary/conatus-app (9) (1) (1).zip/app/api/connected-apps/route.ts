import { type NextRequest, NextResponse } from "next/server"
import { getCurrentUser, getConnectedApps } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const connectedApps = await getConnectedApps(user.id)
    return NextResponse.json({ connectedApps })
  } catch (error) {
    console.error("Error fetching connected apps:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

