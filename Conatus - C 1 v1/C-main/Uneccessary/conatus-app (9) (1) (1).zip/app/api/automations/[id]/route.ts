import { type NextRequest, NextResponse } from "next/server"
import { getCurrentUser, updateAutomation, deleteAutomation } from "@/lib/db"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = params
    const automation = await updateAutomation(id, {})

    if (!automation) {
      return NextResponse.json({ error: "Automation not found" }, { status: 404 })
    }

    // Check if the automation belongs to the user
    if (automation.userId !== user.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    return NextResponse.json({ automation })
  } catch (error) {
    console.error("Error fetching automation:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = params
    const body = await request.json()

    // Get the current automation to check ownership
    const currentAutomation = await updateAutomation(id, {})

    if (!currentAutomation) {
      return NextResponse.json({ error: "Automation not found" }, { status: 404 })
    }

    // Check if the automation belongs to the user
    if (currentAutomation.userId !== user.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const updatedAutomation = await updateAutomation(id, body)

    if (!updatedAutomation) {
      return NextResponse.json({ error: "Failed to update automation" }, { status: 500 })
    }

    return NextResponse.json({ automation: updatedAutomation })
  } catch (error) {
    console.error("Error updating automation:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = params

    // Get the current automation to check ownership
    const currentAutomation = await updateAutomation(id, {})

    if (!currentAutomation) {
      return NextResponse.json({ error: "Automation not found" }, { status: 404 })
    }

    // Check if the automation belongs to the user
    if (currentAutomation.userId !== user.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const success = await deleteAutomation(id)

    if (!success) {
      return NextResponse.json({ error: "Failed to delete automation" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting automation:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

