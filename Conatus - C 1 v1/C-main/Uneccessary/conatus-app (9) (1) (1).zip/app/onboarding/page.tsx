"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { OnboardingFlow } from "@/components/onboarding-flow"
import { DashboardCard } from "@/components/dashboard-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Zap, User, Bell, Calendar } from "lucide-react"

export default function OnboardingPage() {
  const router = useRouter()
  const [name, setName] = useState("")

  const handleComplete = () => {
    router.push("/")
  }

  const steps = [
    {
      title: "Welcome to Conatus",
      description: "Let's get you set up with your personal assistant.",
      content: (
        <div className="flex flex-col items-center justify-center h-full">
          <div className="glass-card p-6 max-w-md w-full">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">What should we call you?</Label>
                <Input id="name" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email address</Label>
                <Input id="email" type="email" placeholder="you@example.com" />
              </div>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Connect Your Apps",
      description: "Conatus works better when connected to your favorite services.",
      content: (
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: "Google Calendar", icon: <Calendar className="h-5 w-5" /> },
            { name: "Slack", icon: <Bell className="h-5 w-5" /> },
            { name: "Spotify", icon: <User className="h-5 w-5" /> },
            { name: "Gmail", icon: <Zap className="h-5 w-5" /> },
          ].map((app) => (
            <DashboardCard key={app.name} className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-accent/10 flex items-center justify-center text-accent">
                  {app.icon}
                </div>
                <span>{app.name}</span>
              </div>
              <Switch />
            </DashboardCard>
          ))}

          <Button className="col-span-2 mt-4">Connect More Apps</Button>
        </div>
      ),
    },
    {
      title: "Choose Your Preferences",
      description: "Customize how Conatus works for you.",
      content: (
        <div className="space-y-6">
          <div className="glass-card p-4">
            <h3 className="font-medium mb-3">Notification Preferences</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label htmlFor="daily-summary">Daily summary</Label>
                <Switch id="daily-summary" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="meeting-reminders">Meeting reminders</Label>
                <Switch id="meeting-reminders" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="automation-suggestions">Automation suggestions</Label>
                <Switch id="automation-suggestions" defaultChecked />
              </div>
            </div>
          </div>

          <div className="glass-card p-4">
            <h3 className="font-medium mb-3">Theme Preferences</h3>
            <div className="grid grid-cols-3 gap-3">
              <Button variant="outline" className="bg-white/20 hover:bg-white/30">
                Light
              </Button>
              <Button variant="outline" className="bg-gray-800/20 hover:bg-gray-800/30">
                Dark
              </Button>
              <Button variant="outline" className="bg-gradient-to-r from-white/20 to-gray-800/20">
                System
              </Button>
            </div>
          </div>
        </div>
      ),
    },
  ]

  return <OnboardingFlow steps={steps} onComplete={handleComplete} onSkip={handleComplete} />
}

