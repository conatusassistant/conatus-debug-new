import type React from "react"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { ToastProvider } from "@/hooks/use-toast"

export const metadata = {
  title: "Conatus - Your Personal Assistant",
  description: "Your personal assistant that learns over time",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="gradient-bg min-h-screen">
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={true}>
          <ToastProvider>
            <div className="max-w-md mx-auto min-h-screen flex flex-col">{children}</div>
          </ToastProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'