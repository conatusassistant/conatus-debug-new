"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import { ConatusLogo } from "@/components/conatus-logo"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { taglines } from "@/lib/taglines"

export default function IntroPage() {
  const router = useRouter()
  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [currentTagline, setCurrentTagline] = useState(taglines[0])
  const [taglineIndex, setTaglineIndex] = useState(0)
  const [activeTab, setActiveTab] = useState("email")

  // Shuffle through taglines
  useEffect(() => {
    const intervalId = setInterval(() => {
      setTaglineIndex((prevIndex) => (prevIndex + 1) % taglines.length)
    }, 3000)

    return () => clearInterval(intervalId)
  }, [])

  useEffect(() => {
    setCurrentTagline(taglines[taglineIndex])
  }, [taglineIndex])

  const handleSignIn = async (e) => {
    e.preventDefault()
    if (!username.trim()) {
      // Show error for missing username
      return
    }

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      router.push("/") // Redirect to home page after successful sign-in
    }, 1500)
  }

  const handleGoogleSignIn = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      router.push("/") // Redirect to home page after successful sign-in
    }, 1500)
  }

  const highlightMainWords = (tagline) => {
    const accentColor = "#3A7B7F" // Existing teal accent
    const sentences = tagline.split(/(?<=[.!?])\s+/)

    const keyWords = [
      "Uber",
      "McDonald's",
      "Zoom",
      "WhatsApp",
      "Spotify",
      "Paris",
      "LinkedIn",
      "Facebook",
      "Instagram",
      "YouTube",
      "Reddit",
      "X",
    ]

    const importantWords = [
      "Book",
      "Order",
      "Schedule",
      "Remind",
      "Alert",
      "Show",
      "Post",
      "Reply",
      "Play",
      "Mute",
      "Text",
      "Tell",
      "Send",
      "Arrange",
      "Create",
      "Manage",
      "Find",
      "Track",
      "Automate",
      "Sync",
      "Connect",
    ]

    return sentences
      .map((sentence) => {
        const words = sentence.split(" ")
        let highlightedWord = false

        const processedWords = words.map((word, index) => {
          if (index === 0) return word // Never highlight the first word
          if (keyWords.includes(word.replace(/[.,!?]$/, ""))) {
            highlightedWord = true
            return `<span class="font-semibold text-[${accentColor}]">${word}</span>`
          }
          return word
        })

        if (!highlightedWord) {
          const eligibleWords = words
            .slice(1)
            .filter((word) => importantWords.includes(word.replace(/[.,!?]$/, "")) || word.length > 3)
          if (eligibleWords.length > 0) {
            const randomWord = eligibleWords[Math.floor(Math.random() * eligibleWords.length)]
            const index = words.indexOf(randomWord)
            processedWords[index] = `<span class="font-semibold text-[${accentColor}]">${randomWord}</span>`
          }
        }

        return processedWords.join(" ")
      })
      .join(" ")
  }

  const highlightedTagline = highlightMainWords(currentTagline)

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F1EA] via-[#EBE5D8] to-[#E1D8C8] flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="flex flex-col items-center mb-8">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 500 }}
            className="mb-6"
          >
            <ConatusLogo className="w-20 h-20 text-[#3A7B7F]" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-3xl font-bold text-[#2D3436] mb-2 text-center"
          >
            conatus
          </motion.h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="h-16 flex items-center justify-center mb-4"
          >
            <div
              className="text-xl text-center text-[#2D3436]/90 transition-opacity duration-500 font-light max-w-xs"
              dangerouslySetInnerHTML={{ __html: highlightedTagline }}
            />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.5 }}
          className="bg-white/30 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-white/20"
        >
          <Tabs defaultValue="email" className="w-full" onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="email">Email</TabsTrigger>
              <TabsTrigger value="google">Google</TabsTrigger>
            </TabsList>

            <TabsContent value="email" className="space-y-4">
              <form onSubmit={handleSignIn} className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="username" className="text-sm font-medium text-[#2D3436]">
                    Username
                  </label>
                  <Input
                    id="username"
                    type="text"
                    placeholder="Choose a username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="bg-white/50 border-[#3A7B7F]/20 focus:border-[#3A7B7F] focus:ring-[#3A7B7F]"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium text-[#2D3436]">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-white/50 border-[#3A7B7F]/20 focus:border-[#3A7B7F] focus:ring-[#3A7B7F]"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="password" className="text-sm font-medium text-[#2D3436]">
                    Password
                  </label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Create a password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-white/50 border-[#3A7B7F]/20 focus:border-[#3A7B7F] focus:ring-[#3A7B7F]"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-[#3A7B7F] hover:bg-[#2A6B6F] text-white"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center">
                      <svg
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Creating your account...
                    </div>
                  ) : (
                    "Sign up with Email"
                  )}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="google">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="google-username" className="text-sm font-medium text-[#2D3436]">
                    Username
                  </label>
                  <Input
                    id="google-username"
                    type="text"
                    placeholder="Choose a username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="bg-white/50 border-[#3A7B7F]/20 focus:border-[#3A7B7F] focus:ring-[#3A7B7F]"
                    required
                  />
                </div>

                <Button
                  onClick={handleGoogleSignIn}
                  className="w-full bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 flex items-center justify-center"
                  disabled={isLoading || !username.trim()}
                >
                  {isLoading ? (
                    <div className="flex items-center">
                      <svg
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-gray-800"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Connecting with Google...
                    </div>
                  ) : (
                    <>
                      <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                        />
                        <path fill="none" d="M1 1h22v22H1z" />
                      </svg>
                      Sign up with Google
                    </>
                  )}
                </Button>
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-6 text-center text-sm text-[#2D3436]/70">
            By signing up, you agree to our{" "}
            <a href="#" className="text-[#3A7B7F] hover:underline">
              Terms of Service
            </a>{" "}
            and{" "}
            <a href="#" className="text-[#3A7B7F] hover:underline">
              Privacy Policy
            </a>
          </div>
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.5 }}
        className="mt-8 text-center text-sm text-[#2D3436]/70"
      >
        Already have an account? <button className="text-[#3A7B7F] hover:underline font-medium">Sign in</button>
      </motion.div>
    </div>
  )
}

