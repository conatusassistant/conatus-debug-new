import { Layout } from "@/components/layout"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

export default function SocialPage() {
  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Community</h1>
          <Button className="bg-accent text-accent-foreground">Share Automation</Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-4">
              <Avatar>
                <AvatarImage src="/user1.png" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-xl font-semibold">John Doe</h2>
                <p className="text-sm text-gray-500">Shared an automation 2h ago</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-4">"Auto-schedule coffee runs every morning at 8 AM."</p>
            <div className="flex justify-between items-center">
              <Button variant="outline">Use This</Button>
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm">
                  Like
                </Button>
                <Button variant="ghost" size="sm">
                  Comment
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Add more social posts here */}
      </div>
    </Layout>
  )
}

