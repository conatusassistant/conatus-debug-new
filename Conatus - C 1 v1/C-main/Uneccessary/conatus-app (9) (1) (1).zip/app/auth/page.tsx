"use client"

import { motion } from "framer-motion"
import { ConatusLogo } from "@/components/conatus-logo"
import { AuthForm } from "@/components/auth-form"
import { useEffect, useState } from "react"
import { taglines } from "@/lib/taglines"

export default function AuthPage() {
  const [currentTagline, setCurrentTagline] = useState(taglines[0])
  const [taglineIndex, setTaglineIndex] = useState(0)

  useEffect(() => {
    const intervalId = setInterval(() => {
      setTaglineIndex((prevIndex) => (prevIndex + 1) % taglines.length)
    }, 3000)

    return () => clearInterval(intervalId)
  }, [])

  useEffect(() => {
    setCurrentTagline(taglines[taglineIndex])
  }, [taglineIndex])

  const highlightMainWords = (tagline) => {
    const accentColor = "#3A7B7F" // Existing teal accent
    const sentences = tagline.split(/(?<=[.!?])\s+/)

    const keyWords = [
      "Uber",
      "McDonald's",
      "Zoom",
      "WhatsApp",
      "Spotify",
      "Paris",
      "LinkedIn",
      "Facebook",
      "Instagram",
      "YouTube",
      "Reddit",
      "X",
    ]

    const importantWords = [
      "Book",
      "Order",
      "Schedule",
      "Remind",
      "Alert",
      "Show",
      "Post",
      "Reply",
      "Play",
      "Mute",
      "Text",
      "Tell",
      "Send",
      "Arrange",
      "Create",
      "Manage",
      "Find",
      "Track",
      "Automate",
      "Sync",
      "Connect",
    ]

    return sentences
      .map((sentence) => {
        const words = sentence.split(" ")
        let highlightedWord = false

        const processedWords = words.map((word, index) => {
          if (index === 0) return word // Never highlight the first word
          if (keyWords.includes(word.replace(/[.,!?]$/, ""))) {
            highlightedWord = true
            return `<span class="font-semibold text-[${accentColor}]">${word}</span>`
          }
          return word
        })

        if (!highlightedWord) {
          const eligibleWords = words
            .slice(1)
            .filter((word) => importantWords.includes(word.replace(/[.,!?]$/, "")) || word.length > 3)
          if (eligibleWords.length > 0) {
            const randomWord = eligibleWords[Math.floor(Math.random() * eligibleWords.length)]
            const index = words.indexOf(randomWord)
            processedWords[index] = `<span class="font-semibold text-[${accentColor}]">${randomWord}</span>`
          }
        }

        return processedWords.join(" ")
      })
      .join(" ")
  }

  const highlightedTagline = highlightMainWords(currentTagline)

  return (
    <div className="min-h-screen gradient-bg flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="flex flex-col items-center mb-8">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 500 }}
            className="mb-6"
          >
            <ConatusLogo className="w-20 h-20 text-accent" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-3xl font-bold mb-2 text-center"
          >
            conatus
          </motion.h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="h-16 flex items-center justify-center mb-4"
          >
            <div
              className="text-xl text-center transition-opacity duration-500 font-light max-w-xs"
              dangerouslySetInnerHTML={{ __html: highlightedTagline }}
            />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.5 }}
          className="bg-white/30 dark:bg-gray-800/30 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-white/20 dark:border-gray-700/20"
        >
          <AuthForm />
        </motion.div>
      </motion.div>
    </div>
  )
}

