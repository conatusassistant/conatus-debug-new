"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { taglines } from "@/lib/taglines"

export function DynamicHeader() {
  const [currentTagline, setCurrentTagline] = useState(taglines[0])
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const intervalId = setInterval(() => {
      setIndex((prevIndex) => (prevIndex + 1) % taglines.length)
    }, 250)

    return () => clearInterval(intervalId)
  }, [])

  useEffect(() => {
    setCurrentTagline(taglines[index])
  }, [index])

  return (
    <header className="flex items-center justify-between p-4 bg-white shadow-sm">
      <div>
        <Link href="/" className="text-2xl font-bold text-primary">
          Conatus
        </Link>
        <p className="text-sm text-gray-500 mt-1 h-5 overflow-hidden transition-all duration-200 ease-in-out">
          {currentTagline}
        </p>
      </div>
      <Avatar>
        <AvatarImage src="/avatar.png" />
        <AvatarFallback>CN</AvatarFallback>
      </Avatar>
    </header>
  )
}

