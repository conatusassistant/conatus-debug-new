"use client"

import { useState } from "react"
import { User, LogOut, Settings, Bell } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { supabase } from "@/lib/db"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

export function UserMenu() {
  const [isOpen, setIsOpen] = useState(false)
  const router = useRouter()
  const { addToast } = useToast()

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut()
      addToast("Signed out successfully", "success")
      router.push("/auth")
    } catch (error) {
      addToast("Failed to sign out", "error")
    }
  }

  return (
    <div className="relative">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="p-2 rounded-full bg-secondary/50 backdrop-blur-sm"
        onClick={() => setIsOpen(!isOpen)}
      >
        <User className="h-5 w-5 text-accent" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 500, damping: 25 }}
            className="absolute right-0 mt-2 w-48 rounded-lg bg-white/20 dark:bg-gray-800/20 backdrop-blur-md shadow-lg border border-white/10 dark:border-gray-700/10 z-50"
          >
            <div className="p-3 border-b border-white/10 dark:border-gray-700/10">
              <p className="text-sm font-medium">User Name</p>
              <p className="text-xs text-foreground/70">user@example.com</p>
            </div>
            <div className="p-2">
              <button
                className="flex items-center gap-2 w-full p-2 text-sm rounded-md hover:bg-white/10 dark:hover:bg-gray-700/10 transition-colors"
                onClick={() => {
                  setIsOpen(false)
                  router.push("/settings")
                }}
              >
                <Settings size={16} />
                <span>Settings</span>
              </button>
              <button
                className="flex items-center gap-2 w-full p-2 text-sm rounded-md hover:bg-white/10 dark:hover:bg-gray-700/10 transition-colors"
                onClick={() => {
                  setIsOpen(false)
                  router.push("/notifications")
                }}
              >
                <Bell size={16} />
                <span>Notifications</span>
              </button>
              <button
                className="flex items-center gap-2 w-full p-2 text-sm rounded-md hover:bg-white/10 dark:hover:bg-gray-700/10 transition-colors text-red-500"
                onClick={handleSignOut}
              >
                <LogOut size={16} />
                <span>Sign Out</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

