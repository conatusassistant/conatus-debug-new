import { SocialFeed } from "./social-feed"

export function SocialView() {
  return (
    <div className="h-full">
      <SocialFeed />
    </div>
  )
}

