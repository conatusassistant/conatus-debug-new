"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { User, Search } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

const SEARCH_PLACEHOLDERS = ["React", "Next.js", "Tailwind CSS", "JavaScript"]

const ALL_POSTS = [
  {
    id: "1",
    author: "John Doe",
    avatar: "/placeholder.svg",
    timestamp: "2 hours ago",
    source: "X",
    content: "Just finished a great coding session!",
    likes: 15,
    comments: 3,
    shares: 1,
  },
  {
    id: "2",
    author: "Jane Smith",
    avatar: "/placeholder.svg",
    timestamp: "1 day ago",
    source: "Reddit",
    content: "Anyone have recommendations for good React libraries?",
    likes: 22,
    comments: 8,
    shares: 5,
  },
  {
    id: "3",
    author: "Alice Johnson",
    avatar: "/placeholder.svg",
    timestamp: "3 days ago",
    source: "News",
    content: "New JavaScript framework gaining popularity.",
    likes: 30,
    comments: 12,
    shares: 7,
  },
]

const X_POSTS = ALL_POSTS.filter((post) => post.source === "X")
const REDDIT_POSTS = ALL_POSTS.filter((post) => post.source === "Reddit")
const NEWS_POSTS = ALL_POSTS.filter((post) => post.source === "News")

export function SocialFeed() {
  const [activeFilter, setActiveFilter] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")
  const [placeholderIndex, setPlaceholderIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setPlaceholderIndex((prevIndex) => (prevIndex + 1) % SEARCH_PLACEHOLDERS.length)
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  const getFilteredPosts = () => {
    switch (activeFilter) {
      case "X":
        return X_POSTS
      case "Reddit":
        return REDDIT_POSTS
      case "News":
        return NEWS_POSTS
      default:
        return ALL_POSTS
    }
  }

  const filteredPosts = getFilteredPosts().filter((post) =>
    post.content.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-[#F5F1EA] via-[#EBE5D8] to-[#E1D8C8]">
      <header className="sticky top-0 z-10 bg-[#FAF9F5]/80 backdrop-blur-sm p-3 pt-2 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="text-2xl font-bold text-[#1A1A1A] leading-tight">Social</h1>
            <p className="text-xs text-[#2D3436]/70">Connect with the community</p>
          </div>
          <Avatar>
            <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
            <AvatarFallback>
              <User className="h-4 w-4" />
            </AvatarFallback>
          </Avatar>
        </div>
        <div className="flex space-x-1 items-center">
          <div className="flex space-x-1 overflow-x-auto">
            {["All", "X", "Reddit", "News"].map((filter) => (
              <Button
                key={filter}
                variant={activeFilter === filter ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveFilter(filter)}
                className={`whitespace-nowrap text-xs py-1 h-7 ${
                  activeFilter === filter
                    ? "bg-[#3A7B7F] text-white"
                    : "bg-[#ECE2D0] text-[#2F2F2F] hover:bg-[#3A7B7F] hover:text-white"
                }`}
              >
                {filter}
              </Button>
            ))}
          </div>
          <div className="relative flex-grow ml-1">
            <Input
              placeholder={`Search ${SEARCH_PLACEHOLDERS[placeholderIndex]}`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-7 pr-2 py-1 h-7 w-full bg-white/70 border-[#ECE2D0] focus:border-[#3A7B7F] focus:ring-[#3A7B7F] text-xs"
            />
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-[#2F2F2F] h-3 w-3" />
          </div>
        </div>
      </header>

      <div className="flex-grow overflow-y-auto p-3 space-y-3 pb-20">
        <CreatePostArea />
        <AnimatePresence>
          {filteredPosts.map((post) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <PostCard post={post} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}

function CreatePostArea() {
  return (
    <div className="bg-white/80 rounded-lg p-3 shadow-sm border border-[#ECE2D0] mb-3">
      <div className="flex items-center space-x-3">
        <Avatar className="h-8 w-8">
          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Your Avatar" />
          <AvatarFallback>You</AvatarFallback>
        </Avatar>
        <Input
          placeholder="What's on your mind?"
          className="flex-grow bg-[#FAF9F5]/50 border-none focus:ring-0 text-sm h-8"
        />
      </div>
      <div className="flex justify-end mt-2">
        <Button size="sm" className="bg-[#3A7B7F] text-white hover:bg-[#2A6B6F] h-7 text-xs">
          Post
        </Button>
      </div>
    </div>
  )
}

function PostCard({ post }) {
  const getSourceBadge = (source) => {
    switch (source) {
      case "X":
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-blue-100 text-blue-800 font-medium">
            X
          </span>
        )
      case "Reddit":
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-orange-100 text-orange-800 font-medium">
            Reddit
          </span>
        )
      case "News":
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-green-100 text-green-800 font-medium">
            News
          </span>
        )
      default:
        return null
    }
  }

  return (
    <motion.div
      className="bg-white/80 rounded-lg p-3 shadow-sm border border-[#ECE2D0]"
      whileHover={{ scale: 1.01 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <div className="flex items-center mb-2">
        <img src={post.avatar || "/placeholder.svg"} alt={post.author} className="w-8 h-8 rounded-full mr-2" />
        <div className="flex-grow">
          <h3 className="font-semibold text-[#1A1A1A] text-sm">{post.author}</h3>
          <div className="flex items-center">
            <p className="text-xs text-[#2F2F2F] mr-2">{post.timestamp}</p>
            {getSourceBadge(post.source)}
          </div>
        </div>
      </div>
      <p className="mb-3 text-sm text-[#2F2F2F]">{post.content}</p>
      <div className="flex justify-between text-xs text-[#2F2F2F] border-t border-[#ECE2D0] pt-2">
        <button className="flex items-center hover:text-[#3A7B7F] transition-colors">
          <span className="mr-1">❤️</span> {post.likes}
        </button>
        <button className="flex items-center hover:text-[#3A7B7F] transition-colors">
          <span className="mr-1">💬</span> {post.comments}
        </button>
        <button className="flex items-center hover:text-[#3A7B7F] transition-colors">
          <span className="mr-1">🔁</span> {post.shares}
        </button>
      </div>
    </motion.div>
  )
}

