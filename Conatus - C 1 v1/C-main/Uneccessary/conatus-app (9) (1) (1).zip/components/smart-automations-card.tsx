"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RefreshCw, ChevronLeft, ChevronRight } from "lucide-react"

export function SmartAutomationsCard() {
  const [isHoveringAccept, setIsHoveringAccept] = useState(false)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold font-montserrat tracking-wide uppercase text-white">Smart Automations</h2>
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card className="bg-zinc-800/50 backdrop-blur-sm border-zinc-700">
        <CardContent className="p-4">
          <div className="flex justify-between">
            <div className="flex gap-3">
              <div className="h-10 w-10 bg-zinc-700 rounded-lg flex items-center justify-center text-neon-blue">
                <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M18 5H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M14 9l-4 6M10 9l4 6"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <div>
                <h3 className="font-bold text-white">Uber Ride</h3>
                <p className="text-sm text-zinc-400">
                  Traffic is light on your preferred route. Would you like to schedule an Uber for your 9 AM meeting?
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 rounded-full self-start text-zinc-400 hover:text-white hover:bg-zinc-700"
            >
              <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M18 6L6 18M6 6l12 12"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </Button>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <Button
              variant="outline"
              size="sm"
              className="border-zinc-600 text-zinc-300 hover:bg-zinc-700 hover:text-white"
            >
              Dismiss
            </Button>
            <Button
              size="sm"
              className={`bg-gradient-to-r from-neon-blue to-neon-pink text-black font-medium transition-all duration-300 ${isHoveringAccept ? "shadow-lg shadow-neon-blue/20" : ""}`}
              onMouseEnter={() => setIsHoveringAccept(true)}
              onMouseLeave={() => setIsHoveringAccept(false)}
            >
              Accept
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center gap-1 mt-2">
        <div className="h-2 w-2 rounded-full bg-neon-blue neon-glow"></div>
        <div className="h-2 w-2 rounded-full bg-zinc-700"></div>
        <div className="h-2 w-2 rounded-full bg-zinc-700"></div>
        <div className="h-2 w-2 rounded-full bg-zinc-700"></div>
      </div>
    </div>
  )
}

