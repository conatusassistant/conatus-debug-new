"use client"

import { useEffect, useState, useRef } from "react"
import { motion } from "framer-motion"

interface TypewriterEffectProps {
  text: string
}

export function TypewriterEffect({ text }: TypewriterEffectProps) {
  const [displayText, setDisplayText] = useState("")
  const [cursorVisible, setCursorVisible] = useState(true)
  const previousTextRef = useRef("")

  // Handle cursor blinking
  useEffect(() => {
    const cursorInterval = setInterval(() => {
      setCursorVisible((prev) => !prev)
    }, 530)

    return () => clearInterval(cursorInterval)
  }, [])

  // Handle text updates with better performance
  useEffect(() => {
    // If text is being deleted, update immediately
    if (text.length < previousTextRef.current.length) {
      setDisplayText(text)
      previousTextRef.current = text
      return
    }

    // If text is being added, animate only the new characters
    if (text !== previousTextRef.current) {
      const commonLength = displayText.length
      const newPortion = text.slice(commonLength)

      if (newPortion) {
        let index = 0
        const typingInterval = setInterval(() => {
          if (index < newPortion.length) {
            setDisplayText((current) => current + newPortion[index])
            index++
          } else {
            clearInterval(typingInterval)
          }
        }, 20) // Faster typing speed

        return () => clearInterval(typingInterval)
      }
    }

    previousTextRef.current = text
  }, [text, displayText])

  return (
    <div className="absolute inset-0 pointer-events-none flex items-center pl-12 pr-10">
      <div className="flex items-center">
        {displayText.split("").map((char, index) => (
          <motion.span
            key={`${index}-${char}`}
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1 }}
            className="text-foreground text-sm"
          >
            {char === " " ? "\u00A0" : char}
          </motion.span>
        ))}
        <motion.span
          animate={{ opacity: cursorVisible ? 1 : 0 }}
          transition={{ duration: 0.2 }}
          className="w-[1px] h-5 bg-foreground ml-[1px]"
        />
      </div>
    </div>
  )
}

