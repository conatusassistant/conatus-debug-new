"use client"

import { ConatusLogo } from "@/components/conatus-logo"

const accentColor = "#3A7B7F" // Existing teal accent

function highlightMainWords(tagline) {
  const sentences = tagline.split(/(?<=[.!?])\s+/)

  const keyWords = [
    "Uber",
    "McDonald's",
    "Zoom",
    "WhatsApp",
    "Spotify",
    "Paris",
    "LinkedIn",
    "Facebook",
    "Instagram",
    "YouTube",
    "Reddit",
    "X",
  ]

  const importantWords = [
    "Book",
    "Order",
    "Schedule",
    "Remind",
    "Alert",
    "Show",
    "Post",
    "Reply",
    "Play",
    "Mute",
    "Text",
    "Tell",
    "Send",
    "Arrange",
    "Create",
    "Manage",
    "Find",
    "Track",
    "Automate",
    "Sync",
    "Connect",
  ]

  return sentences
    .map((sentence) => {
      const words = sentence.split(" ")
      let highlightedWord = false

      const processedWords = words.map((word, index) => {
        if (index === 0) return word // Never highlight the first word
        if (keyWords.includes(word.replace(/[.,!?]$/, ""))) {
          highlightedWord = true
          return `<span class="font-semibold text-[${accentColor}]">${word}</span>`
        }
        return word
      })

      if (!highlightedWord) {
        const eligibleWords = words
          .slice(1)
          .filter((word) => importantWords.includes(word.replace(/[.,!?]$/, "")) || word.length > 3)
        if (eligibleWords.length > 0) {
          const randomWord = eligibleWords[Math.floor(Math.random() * eligibleWords.length)]
          const index = words.indexOf(randomWord)
          processedWords[index] = `<span class="font-semibold text-[${accentColor}]">${randomWord}</span>`
        }
      }

      return processedWords.join(" ")
    })
    .join(" ")
}

export function DashboardView({ currentTagline }) {
  const highlightedTagline = highlightMainWords(currentTagline)

  return (
    <div className="flex flex-col items-center justify-center h-full px-4 py-12">
      <div className="flex-grow"></div>
      <ConatusLogo className="w-16 h-16 text-[#3A7B7F] mb-8" />
      <div className="h-20 flex items-center justify-center">
        <div
          className="text-2xl text-center text-foreground/90 transition-opacity duration-500 font-light max-w-xs"
          dangerouslySetInnerHTML={{ __html: highlightedTagline }}
        />
      </div>
      <div className="flex-grow"></div>
    </div>
  )
}

