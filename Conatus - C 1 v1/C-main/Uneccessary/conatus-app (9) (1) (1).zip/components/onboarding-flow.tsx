"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ConatusLogo } from "@/components/conatus-logo"
import { ChevronLeft, ChevronRight, Check } from "lucide-react"

interface OnboardingStep {
  title: string
  description: string
  content: React.ReactNode
}

interface OnboardingFlowProps {
  steps: OnboardingStep[]
  onComplete: () => void
  onSkip?: () => void
}

export function OnboardingFlow({ steps, onComplete, onSkip }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [completed, setCompleted] = useState<number[]>([])

  const handleNext = () => {
    if (!completed.includes(currentStep)) {
      setCompleted([...completed, currentStep])
    }

    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      onComplete()
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSkip = () => {
    if (onSkip) {
      onSkip()
    } else {
      onComplete()
    }
  }

  return (
    <div className="min-h-screen animated-gradient flex flex-col">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ConatusLogo className="h-6 w-6 text-accent" />
          <h1 className="text-xl font-semibold text-foreground">conatus</h1>
        </div>

        {onSkip && (
          <Button variant="ghost" size="sm" onClick={handleSkip}>
            Skip
          </Button>
        )}
      </div>

      {/* Progress bar */}
      <div className="px-4 flex gap-1">
        {steps.map((_, index) => (
          <div
            key={index}
            className={`h-1 flex-grow rounded-full transition-colors ${
              index === currentStep ? "bg-accent" : completed.includes(index) ? "bg-accent/50" : "bg-muted"
            }`}
          />
        ))}
      </div>

      {/* Content */}
      <div className="flex-grow flex flex-col p-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="flex-grow flex flex-col"
          >
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-foreground mb-2">{steps[currentStep].title}</h2>
              <p className="text-muted-foreground">{steps[currentStep].description}</p>
            </div>

            <div className="flex-grow">{steps[currentStep].content}</div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation */}
      <div className="p-4 flex justify-between">
        <Button variant="outline" onClick={handleBack} disabled={currentStep === 0} className="w-24">
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back
        </Button>

        <div className="flex items-center gap-1">
          {steps.map((_, index) => (
            <button
              key={index}
              className={`w-2 h-2 rounded-full transition-colors ${
                index === currentStep ? "bg-accent" : completed.includes(index) ? "bg-accent/50" : "bg-muted"
              }`}
              onClick={() => setCurrentStep(index)}
            />
          ))}
        </div>

        <Button onClick={handleNext} className="w-24">
          {currentStep === steps.length - 1 ? (
            <>
              Done
              <Check className="ml-2 h-4 w-4" />
            </>
          ) : (
            <>
              Next
              <ChevronRight className="ml-2 h-4 w-4" />
            </>
          )}
        </Button>
      </div>
    </div>
  )
}

