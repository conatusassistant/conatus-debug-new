"use client"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Search, Home, BookOpen, Users, Image, X, FileText, Clock } from "lucide-react"
import { IntelligentAutocomplete } from "./intelligent-autocomplete"
import { TypewriterEffect } from "./typewriter-effect"

interface BottomNavigationProps {
  activeTab: string
  setActiveTab: (tab: string) => void
}

export function BottomNavigation({ activeTab, setActiveTab }: BottomNavigationProps) {
  const [isInputFocused, setIsInputFocused] = useState(false)
  const [inputValue, setInputValue] = useState("")
  const [showNotes, setShowNotes] = useState(false)
  const inputRef = useRef(null)
  const fileInputRef = useRef(null)

  useEffect(() => {
    if (isInputFocused) {
      inputRef.current?.focus()
    }
  }, [isInputFocused])

  const handleImageClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      // Here you would typically handle the image upload
      // For now, we'll just show the filename in the input
      setInputValue(`Uploading: ${file.name}`)
    }
  }

  const searchBarVariants = {
    focused: {
      height: 56,
      boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
      backgroundColor: "rgba(255, 255, 255, 0.15)",
    },
    unfocused: {
      height: 48,
      boxShadow: "0 2px 4px rgba(0, 0, 0, 0.05)",
      backgroundColor: "rgba(255, 255, 255, 0.1)",
    },
  }

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 500, damping: 25 }}
      className="p-4 pb-6 bg-secondary/60 backdrop-blur-md fixed bottom-0 left-0 right-0 max-w-md mx-auto"
    >
      {/* Hidden file input for image upload */}
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />

      {/* Search Bar - Only shown on home tab with smooth animation */}
      <AnimatePresence mode="popLayout">
        {activeTab === "home" && (
          <motion.div
            layout
            initial={{ opacity: 0, y: 10, height: 0 }}
            animate={{
              opacity: 1,
              y: 0,
              height: isInputFocused ? 56 : 48,
              boxShadow: isInputFocused ? "0 4px 12px rgba(0, 0, 0, 0.1)" : "0 2px 4px rgba(0, 0, 0, 0.05)",
              backgroundColor: isInputFocused ? "rgba(255, 255, 255, 0.15)" : "rgba(255, 255, 255, 0.1)",
            }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            transition={{
              type: "spring",
              stiffness: 700,
              damping: 25,
              opacity: { duration: 0.15 },
            }}
            className="search-bar mb-4 relative rounded-full overflow-hidden flex items-center"
          >
            {/* Search Icon - Fixed positioning */}
            <div className="absolute left-0 top-0 bottom-0 flex items-center justify-center w-12 z-10">
              <Search className="text-accent" size={18} />
            </div>

            {/* Input Field */}
            <motion.input
              ref={inputRef}
              layout
              type="text"
              className="bg-transparent border-none focus:outline-none flex-grow text-foreground text-sm placeholder-muted-foreground/70 font-light pl-12 pr-24 py-3 w-full absolute inset-0 z-20"
              style={{ caretColor: "currentColor" }}
              onFocus={() => setIsInputFocused(true)}
              onBlur={() => {
                setTimeout(() => {
                  if (inputValue === "") {
                    setIsInputFocused(false)
                  }
                }, 100)
              }}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
            />

            {/* Placeholder Text */}
            <motion.div className="pl-12 pr-4 py-2 text-sm text-foreground/70 flex-grow pointer-events-none" layout>
              {!isInputFocused && !inputValue && (
                <span className="transition-opacity duration-200">Think it, Type it, Done.</span>
              )}
            </motion.div>

            {/* Typewriter Effect */}
            {(isInputFocused || inputValue) && <TypewriterEffect text={inputValue} />}

            {/* Action Buttons Container */}
            <motion.div className="absolute right-0 top-0 bottom-0 flex items-center pr-4 gap-2 z-30" layout>
              {/* Image Button */}
              <AnimatePresence mode="popLayout">
                {(isInputFocused || inputValue) && (
                  <motion.button
                    initial={{ opacity: 0, scale: 0.8, width: 0 }}
                    animate={{ opacity: 1, scale: 1, width: "auto" }}
                    exit={{ opacity: 0, scale: 0.8, width: 0 }}
                    transition={{ type: "spring", stiffness: 700, damping: 25 }}
                    className="text-accent flex items-center justify-center hover:text-accent/80 transition-colors"
                    onClick={handleImageClick}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Image size={18} />
                  </motion.button>
                )}
              </AnimatePresence>

              {/* Notes Button */}
              <motion.button
                layout
                className="text-accent hover:text-accent/80 transition-colors ml-1"
                onClick={() => setShowNotes(!showNotes)}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <FileText size={18} />
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <IntelligentAutocomplete isVisible={isInputFocused} inputValue={inputValue} />

      {/* Improved Notes Panel with Better Exit Animation */}
      <AnimatePresence mode="popLayout">
        {showNotes && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{
              opacity: 0,
              y: -8,
              scale: 0.98,
              filter: "blur(2px)",
              transition: {
                duration: 0.25,
                ease: [0.32, 0.72, 0, 1],
              },
            }}
            transition={{
              type: "spring",
              stiffness: 600,
              damping: 20,
              mass: 0.5,
              velocity: 3,
            }}
            className="bg-white/15 backdrop-blur-md rounded-xl mb-4 border border-accent/10 overflow-hidden shadow-lg"
          >
            {/* Header with gradient */}
            <div className="bg-gradient-to-r from-accent/20 to-transparent px-4 py-3 flex justify-between items-center border-b border-accent/10">
              <div className="flex items-center gap-2">
                <FileText size={16} className="text-accent" />
                <h3 className="text-sm font-medium text-foreground">Recent Conversations</h3>
              </div>
              <motion.button
                className="text-accent/70 hover:text-accent rounded-full w-6 h-6 flex items-center justify-center hover:bg-white/10 transition-colors"
                onClick={() => setShowNotes(false)}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <X size={14} />
              </motion.button>
            </div>

            {/* Content area with subtle scrollbar */}
            <div className="max-h-60 overflow-y-auto py-2 px-3 scrollbar-thin">
              {[
                {
                  title: "Morning routine setup",
                  date: "Today",
                  preview: "Schedule coffee delivery and news briefing",
                },
                {
                  title: "Travel planning",
                  date: "Yesterday",
                  preview: "Book flights to Paris and hotel reservations",
                },
                { title: "Work automation", date: "Mar 12", preview: "Email scheduling and meeting preparation" },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{
                    delay: index * 0.05,
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                  }}
                  className="p-2.5 mb-2 hover:bg-white/10 rounded-lg cursor-pointer transition-all border border-transparent hover:border-accent/10 hover:translate-x-0.5"
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-medium text-sm text-foreground">{item.title}</span>
                    <div className="flex items-center text-xs text-foreground/50 gap-1">
                      <Clock size={10} />
                      <span>{item.date}</span>
                    </div>
                  </div>
                  <p className="text-xs text-foreground/70 truncate">{item.preview}</p>
                </motion.div>
              ))}
            </div>

            {/* Footer with action button */}
            <div className="border-t border-accent/10 p-3 bg-white/5">
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{
                  delay: 0.2,
                  type: "spring",
                  stiffness: 400,
                  damping: 25,
                }}
                className="w-full text-center text-xs py-2 rounded-lg bg-accent/10 hover:bg-accent/20 text-accent font-medium transition-all"
                whileHover={{
                  scale: 1.02,
                  backgroundColor: "rgba(58, 123, 127, 0.25)",
                }}
                whileTap={{ scale: 0.98 }}
              >
                View All Conversations
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Segmented Control Style */}
      <div className="bg-white/10 backdrop-blur-sm p-1.5 rounded-xl flex justify-between">
        {["library", "home", "social"].map((tab) => (
          <motion.button
            key={tab}
            className={`flex items-center justify-center py-2 px-4 rounded-lg relative ${
              activeTab === tab ? "" : "hover:bg-white/5"
            }`}
            onClick={() => setActiveTab(tab)}
            whileTap={{ scale: 0.95 }}
          >
            {activeTab === tab && (
              <motion.div
                className="absolute inset-0 bg-accent rounded-lg"
                layoutId="segmentedBackground"
                transition={{ type: "spring", stiffness: 800, damping: 25 }}
              />
            )}

            <div className="flex items-center gap-2 relative z-10">
              {tab === "library" && (
                <BookOpen size={18} className={activeTab === tab ? "text-white" : "text-muted-foreground"} />
              )}
              {tab === "home" && (
                <Home size={18} className={activeTab === tab ? "text-white" : "text-muted-foreground"} />
              )}
              {tab === "social" && (
                <Users size={18} className={activeTab === tab ? "text-white" : "text-muted-foreground"} />
              )}

              <span className={`text-sm font-medium ${activeTab === tab ? "text-white" : "text-muted-foreground"}`}>
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </span>
            </div>
          </motion.button>
        ))}
      </div>
    </motion.div>
  )
}

