"use client"

import { cn } from "@/lib/utils"
import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface DashboardCardProps {
  title?: string
  subtitle?: string
  icon?: ReactNode
  className?: string
  children: ReactNode
  onClick?: () => void
  hoverEffect?: boolean
}

export function DashboardCard({
  title,
  subtitle,
  icon,
  className,
  children,
  onClick,
  hoverEffect = true,
}: DashboardCardProps) {
  return (
    <motion.div
      whileHover={hoverEffect ? { y: -4, scale: 1.01 } : {}}
      whileTap={onClick ? { scale: 0.98 } : {}}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
      onClick={onClick}
      className={cn("glass-card p-4 overflow-hidden", onClick && "cursor-pointer", className)}
    >
      {(title || icon) && (
        <div className="flex items-center justify-between mb-3">
          {title && (
            <div>
              <h3 className="font-medium text-foreground">{title}</h3>
              {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
            </div>
          )}
          {icon && <div className="text-accent">{icon}</div>}
        </div>
      )}
      <div>{children}</div>
    </motion.div>
  )
}

