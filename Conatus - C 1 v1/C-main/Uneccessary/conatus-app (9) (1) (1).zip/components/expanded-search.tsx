"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Search, X, Mic, Image, HelpCircle } from "lucide-react"
import { taglines } from "@/lib/taglines"

export function ExpandedSearch({ isExpanded, onClose }) {
  const [currentTagline, setCurrentTagline] = useState(taglines[0])
  const [taglineIndex, setTaglineIndex] = useState(0)
  const inputRef = useRef(null)

  useEffect(() => {
    if (isExpanded) {
      inputRef.current?.focus()
    }
  }, [isExpanded])

  useEffect(() => {
    const intervalId = setInterval(() => {
      setTaglineIndex((prevIndex) => (prevIndex + 1) % taglines.length)
    }, 3000)

    return () => clearInterval(intervalId)
  }, [])

  useEffect(() => {
    setCurrentTagline(taglines[taglineIndex])
  }, [taglineIndex])

  return (
    <AnimatePresence>
      {isExpanded && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ duration: 0.3 }}
          className="absolute inset-x-0 top-0 bg-background/95 backdrop-blur-sm z-50 p-4"
        >
          <div className="relative max-w-3xl mx-auto">
            <input
              ref={inputRef}
              type="text"
              placeholder={currentTagline}
              className="w-full bg-white/10 backdrop-blur-sm border border-accent/20 rounded-full py-4 px-6 pr-12 text-lg focus:outline-none focus:ring-2 focus:ring-accent/30 transition-all duration-300"
            />
            <button className="absolute right-3 top-1/2 -translate-y-1/2 text-accent">
              <Search className="w-6 h-6" />
            </button>
          </div>
          <div className="flex justify-center mt-4 space-x-4">
            <button className="text-accent hover:text-accent/80 transition-colors">
              <Mic className="w-6 h-6" />
            </button>
            <button className="text-accent hover:text-accent/80 transition-colors">
              <Image className="w-6 h-6" />
            </button>
            <button className="text-accent hover:text-accent/80 transition-colors">
              <HelpCircle className="w-6 h-6" />
            </button>
          </div>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-accent hover:text-accent/80 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

