"use client"

import React, { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Home, BookOpen, Users, Settings, Bell, Search } from "lucide-react"
import { usePathname } from "next/navigation"
import { ConatusHeader } from "@/components/conatus-header"
import { BottomNavigation } from "@/components/bottom-navigation"
import { ToastProvider } from "@/components/ui/toast"
import { ThemeProvider } from "@/components/theme-provider"
import { SidebarProvider, Sidebar } from "@/components/ui/sidebar"

const pageVariants = {
  initial: { opacity: 0, y: 20 },
  in: { opacity: 1, y: 0 },
  out: { opacity: 0, y: -20 },
}

const pageTransition = {
  type: "tween",
  ease: "anticipate",
  duration: 0.3,
}

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [activeTab, setActiveTab] = useState("home")
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  // Determine active tab from pathname
  React.useEffect(() => {
    if (pathname === "/") {
      setActiveTab("home")
    } else if (pathname.includes("/library")) {
      setActiveTab("library")
    } else if (pathname.includes("/social")) {
      setActiveTab("social")
    }
  }, [pathname])

  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={true}>
      <ToastProvider>
        <SidebarProvider defaultOpen={false} open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <div className="gradient-bg min-h-screen">
            <div className="max-w-md mx-auto min-h-screen flex flex-col">
              <ConatusHeader onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

              <main className="flex-grow flex items-center justify-center overflow-hidden relative">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial="initial"
                    animate="in"
                    exit="out"
                    variants={pageVariants}
                    transition={pageTransition}
                    className="w-full h-full"
                  >
                    {children}
                  </motion.div>
                </AnimatePresence>
              </main>

              <BottomNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
            </div>

            <Sidebar variant="floating" collapsible="offcanvas">
              <div className="p-4 border-b border-border/10">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-white">C</div>
                  <div>
                    <h3 className="font-medium text-sm">Conatus</h3>
                    <p className="text-xs text-foreground/70">Your personal assistant</p>
                  </div>
                </div>
              </div>

              <div className="p-4 space-y-4">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search..."
                    className="w-full bg-white/10 rounded-lg py-2 pl-9 pr-3 text-sm border border-border/10 focus:border-accent focus:ring-1 focus:ring-accent"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-foreground/50" size={16} />
                </div>

                <div className="space-y-1">
                  <button className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white/10 text-sm">
                    <Home size={18} />
                    <span>Home</span>
                  </button>
                  <button className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white/10 text-sm">
                    <BookOpen size={18} />
                    <span>Library</span>
                  </button>
                  <button className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white/10 text-sm">
                    <Users size={18} />
                    <span>Social</span>
                  </button>
                </div>
              </div>

              <div className="mt-auto p-4 border-t border-border/10">
                <button className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white/10 text-sm">
                  <Settings size={18} />
                  <span>Settings</span>
                </button>
                <button className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white/10 text-sm">
                  <Bell size={18} />
                  <span>Notifications</span>
                </button>
              </div>
            </Sidebar>
          </div>
        </SidebarProvider>
      </ToastProvider>
    </ThemeProvider>
  )
}

