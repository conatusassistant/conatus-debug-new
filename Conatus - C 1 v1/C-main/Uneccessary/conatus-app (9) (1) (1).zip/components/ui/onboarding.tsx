"use client"

import * as React from "react"
import { motion } from "framer-motion"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"

export interface OnboardingStep {
  title: string
  description: string
  target: string
  placement?: "top" | "right" | "bottom" | "left"
}

export interface OnboardingProps {
  steps: OnboardingStep[]
  onComplete?: () => void
  onSkip?: () => void
}

export function Onboarding({ steps, onComplete, onSkip }: OnboardingProps) {
  const [currentStep, setCurrentStep] = React.useState(0)
  const [targetElement, setTargetElement] = React.useState<DOMRect | null>(null)

  const getCurrentStep = () => steps[currentStep]

  React.useEffect(() => {
    const updateTargetPosition = () => {
      const target = document.querySelector(getCurrentStep().target)
      if (target) {
        setTargetElement(target.getBoundingClientRect())
      }
    }

    updateTargetPosition()

    window.addEventListener("resize", updateTargetPosition)
    return () => window.removeEventListener("resize", updateTargetPosition)
  }, [currentStep])

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      onComplete?.()
    }
  }

  const handleSkip = () => {
    onSkip?.()
  }

  const getTooltipPosition = () => {
    if (!targetElement) return { top: "50%", left: "50%" }

    const step = getCurrentStep()
    const placement = step.placement || "bottom"

    switch (placement) {
      case "top":
        return {
          bottom: `${window.innerHeight - targetElement.top + 10}px`,
          left: `${targetElement.left + targetElement.width / 2}px`,
          transform: "translateX(-50%)",
        }
      case "right":
        return {
          top: `${targetElement.top + targetElement.height / 2}px`,
          left: `${targetElement.right + 10}px`,
          transform: "translateY(-50%)",
        }
      case "bottom":
        return {
          top: `${targetElement.bottom + 10}px`,
          left: `${targetElement.left + targetElement.width / 2}px`,
          transform: "translateX(-50%)",
        }
      case "left":
        return {
          top: `${targetElement.top + targetElement.height / 2}px`,
          right: `${window.innerWidth - targetElement.left + 10}px`,
          transform: "translateY(-50%)",
        }
    }
  }

  if (!targetElement) return null

  return (
    <div className="fixed inset-0 z-50 pointer-events-none">
      {/* Overlay with cutout */}
      <div className="absolute inset-0 bg-black/50 pointer-events-auto" />

      {/* Highlight target element */}
      <div
        className="absolute rounded-lg ring-2 ring-accent ring-offset-2 pointer-events-none"
        style={{
          top: targetElement.top - 4,
          left: targetElement.left - 4,
          width: targetElement.width + 8,
          height: targetElement.height + 8,
        }}
      />

      {/* Tooltip */}
      <motion.div
        className="absolute glass-card p-4 max-w-xs pointer-events-auto"
        style={getTooltipPosition()}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.2 }}
      >
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-medium">{getCurrentStep().title}</h3>
          <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full -mt-1 -mr-1" onClick={handleSkip}>
            <X size={14} />
          </Button>
        </div>
        <p className="text-sm text-foreground/70 mb-4">{getCurrentStep().description}</p>
        <div className="flex justify-between items-center">
          <div className="flex gap-1">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`h-1.5 w-1.5 rounded-full ${index === currentStep ? "bg-accent" : "bg-accent/30"}`}
              />
            ))}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleSkip}>
              Skip
            </Button>
            <Button size="sm" onClick={handleNext}>
              {currentStep < steps.length - 1 ? "Next" : "Finish"}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

