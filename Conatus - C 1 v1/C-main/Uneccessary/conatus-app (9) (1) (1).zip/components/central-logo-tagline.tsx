"use client"

import { useState, useEffect } from "react"
import { ConatusLogo } from "./conatus-logo"
import { taglines } from "@/lib/taglines"

export function CentralLogoTagline() {
  const [currentTagline, setCurrentTagline] = useState(taglines[0])
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const intervalId = setInterval(() => {
      setIndex((prevIndex) => (prevIndex + 1) % taglines.length)
    }, 250)

    return () => clearInterval(intervalId)
  }, [])

  useEffect(() => {
    setCurrentTagline(taglines[index])
  }, [index])

  return (
    <div className="flex flex-col items-center justify-center h-full">
      <ConatusLogo className="text-primary mb-4" size={64} />
      <h1 className="text-3xl font-bold text-primary mb-2">Conatus</h1>
      <p className="text-lg text-gray-600 h-7 overflow-hidden transition-all duration-200 ease-in-out text-center">
        {currentTagline}
      </p>
    </div>
  )
}

