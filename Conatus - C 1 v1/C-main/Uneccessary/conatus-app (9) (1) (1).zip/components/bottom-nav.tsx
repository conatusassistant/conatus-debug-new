"use client"

import { Home, Zap, Users } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t flex justify-around py-2 px-4">
      <Link
        href="/automations"
        className={cn("flex flex-col items-center text-gray-500", pathname === "/automations" && "text-blue-500")}
      >
        <Zap className="h-6 w-6" />
        <span className="text-xs mt-1">Automations</span>
      </Link>

      <Link href="/" className={cn("flex flex-col items-center text-gray-500", pathname === "/" && "text-blue-500")}>
        <div className="bg-blue-500 rounded-full p-3 -mt-6 border-4 border-white">
          <Home className="h-6 w-6 text-white" />
        </div>
        <span className="text-xs mt-1">Home</span>
      </Link>

      <Link
        href="/social"
        className={cn("flex flex-col items-center text-gray-500", pathname === "/social" && "text-blue-500")}
      >
        <Users className="h-6 w-6" />
        <span className="text-xs mt-1">Social</span>
      </Link>
    </nav>
  )
}

