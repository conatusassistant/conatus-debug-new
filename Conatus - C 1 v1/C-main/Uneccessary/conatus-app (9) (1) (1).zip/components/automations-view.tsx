import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Clock, Calendar, Plus } from "lucide-react"
import { Switch } from "@/components/ui/switch"

export function AutomationsView() {
  return (
    <div className="p-6 space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2">Automate Your Life</h2>
        <p className="text-muted-foreground mb-6">Connect your favorite apps to create powerful automations</p>

        <div className="grid grid-cols-3 gap-4 mb-8">
          {["Venmo", "Cash App", "Google Calendar", "DoorDash", "Spotify", "Uber"].map((app, index) => (
            <div key={app} className="flex flex-col items-center">
              <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center mb-2 shadow-lg shadow-primary/10">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-primary to-blue-400 flex items-center justify-center text-white font-bold text-lg">
                  {app[0]}
                </div>
              </div>
              <span className="text-sm font-medium">{app}</span>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold">My Automations</h2>
          <Button variant="ghost" size="sm" className="text-primary">
            View All
          </Button>
        </div>
        <p className="text-muted-foreground mb-6">Your personal automation library</p>

        <Tabs defaultValue="personal" className="w-full mb-6">
          <TabsList className="grid w-full grid-cols-2 glass-effect p-1 rounded-xl">
            <TabsTrigger value="personal" className="rounded-lg">
              Personal
            </TabsTrigger>
            <TabsTrigger value="community" className="rounded-lg">
              Community
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="space-y-4">
          {[
            {
              title: "Executive Morning Routine",
              description: "Arrange transportation, review calendar, order coffee",
            },
            { title: "Concierge Lunch Service", description: "Order your preferred meal at noon on weekdays" },
            { title: "Meeting Preparation", description: "Gather documents and send reminders" },
          ].map((automation, index) => (
            <Card key={automation.title} className="overflow-hidden card-hover">
              <CardContent className="p-0">
                <div className="flex items-center gap-4 p-4">
                  <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
                    {index === 0 ? (
                      <Clock className="h-6 w-6 text-primary" />
                    ) : (
                      <Calendar className="h-6 w-6 text-primary" />
                    )}
                  </div>
                  <div className="flex-grow">
                    <h3 className="font-semibold">{automation.title}</h3>
                    <p className="text-sm text-muted-foreground">{automation.description}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch defaultChecked={index < 2} />
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

