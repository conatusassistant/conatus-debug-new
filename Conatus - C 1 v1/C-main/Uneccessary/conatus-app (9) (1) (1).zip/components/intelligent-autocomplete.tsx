"use client"

import { motion, AnimatePresence } from "framer-motion"
import { useState, useEffect } from "react"

const suggestions = [
  "Book an Uber ride",
  "Order coffee from Starbucks",
  "Schedule a Zoom meeting",
  "Send money via Venmo",
  "Play Spotify playlist",
  "Set a reminder for tomorrow",
  "Check flight prices to Paris",
  "Order groceries from Instacart",
  "Book a table at a restaurant",
  "Start a workout on Fitbit",
]

export function IntelligentAutocomplete({ inputValue, isVisible }) {
  const [filteredSuggestions, setFilteredSuggestions] = useState([])

  useEffect(() => {
    const filtered = suggestions.filter((suggestion) => suggestion.toLowerCase().includes(inputValue.toLowerCase()))
    setFilteredSuggestions(filtered.slice(0, 5)) // Limit to 5 suggestions
  }, [inputValue])

  return (
    <AnimatePresence>
      {isVisible && filteredSuggestions.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="absolute left-0 right-0 top-full mt-2 bg-white/10 backdrop-blur-md rounded-xl overflow-hidden shadow-lg"
        >
          {filteredSuggestions.map((suggestion, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="px-4 py-3 hover:bg-white/10 transition-colors cursor-pointer"
            >
              {highlightMatch(suggestion, inputValue)}
            </motion.div>
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  )
}

function highlightMatch(text, query) {
  if (!query) return text

  const parts = text.split(new RegExp(`(${query})`, "gi"))
  return (
    <span>
      {parts.map((part, index) =>
        part.toLowerCase() === query.toLowerCase() ? (
          <motion.span
            key={index}
            initial={{ backgroundColor: "rgba(58, 123, 127, 0.3)" }}
            animate={{ backgroundColor: "rgba(58, 123, 127, 0.6)" }}
            transition={{ duration: 0.3 }}
            className="font-semibold"
          >
            {part}
          </motion.span>
        ) : (
          part
        ),
      )}
    </span>
  )
}

