"use client"

import { motion, AnimatePresence } from "framer-motion"

const suggestions = [
  { icon: "🚗", text: "Book an Uber ride" },
  { icon: "☕", text: "Order coffee" },
  { icon: "📅", text: "Schedule a meeting" },
  { icon: "💰", text: "Send money via Venmo" },
  { icon: "🎵", text: "Play Spotify playlist" },
]

export function AnimatedSearchSuggestions({ isVisible, inputValue }) {
  const filteredSuggestions = suggestions.filter((suggestion) =>
    suggestion.text.toLowerCase().includes(inputValue.toLowerCase()),
  )

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="absolute left-0 right-0 top-full mt-2 bg-white/10 backdrop-blur-md rounded-xl overflow-hidden shadow-lg"
        >
          {filteredSuggestions.map((suggestion, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="flex items-center px-4 py-3 hover:bg-white/10 transition-colors cursor-pointer"
            >
              <span className="text-2xl mr-3">{suggestion.icon}</span>
              <span className="text-sm text-foreground">{suggestion.text}</span>
            </motion.div>
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  )
}

