"use client"

import { Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export function DateSection() {
  const [isHovering, setIsHovering] = useState(false)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold font-montserrat tracking-wide uppercase text-white">Sunday, March 9</h2>
        <Button variant="ghost" size="sm" className="text-zinc-400">
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </Button>
      </div>

      <Button
        className={`w-full bg-gradient-to-r from-neon-blue to-neon-pink text-black font-bold py-6 rounded-xl transition-all duration-300 ${isHovering ? "animate-pulse shadow-lg shadow-neon-blue/20" : ""}`}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
      >
        <Sparkles className="h-5 w-5 mr-2" />
        OPTIMIZE MY DAY
      </Button>

      <div className="h-1 bg-gradient-to-r from-neon-blue to-neon-pink rounded-full w-2/3"></div>
    </div>
  )
}

