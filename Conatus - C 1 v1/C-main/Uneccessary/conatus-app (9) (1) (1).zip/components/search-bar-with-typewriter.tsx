"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Search, X, Image } from "lucide-react"
import { TypewriterEffect } from "./typewriter-effect"

interface SearchBarWithTypewriterProps {
  placeholder?: string
  onSearch?: (value: string) => void
  className?: string
}

export function SearchBarWithTypewriter({
  placeholder = "Think it, Type it, Done.",
  onSearch,
  className = "",
}: SearchBarWithTypewriterProps) {
  const [isInputFocused, setIsInputFocused] = useState(false)
  const [inputValue, setInputValue] = useState("")
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (isInputFocused) {
      inputRef.current?.focus()
    }
  }, [isInputFocused])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value)
    onSearch && onSearch(e.target.value)
  }

  const handleClearInput = () => {
    setInputValue("")
    setIsInputFocused(false)
    onSearch && onSearch("")
  }

  const renderPlaceholder = () => {
    const parts = placeholder.split(/(Type it)/)
    return (
      <span className="placeholder-text">
        {parts.map((part, index) =>
          part === "Type it" ? (
            <span key={index} className="highlight-green">
              {part}
            </span>
          ) : (
            <span key={index}>{part}</span>
          ),
        )}
      </span>
    )
  }

  return (
    <div
      className={`search-bar relative rounded-full overflow-hidden flex items-center ${
        isInputFocused ? "focused" : ""
      } ${className}`}
    >
      <Search className="text-accent absolute left-4 top-1/2 transform -translate-y-1/2 z-10" size={20} />
      <input
        ref={inputRef}
        type="text"
        placeholder={isInputFocused ? "" : placeholder}
        className="bg-transparent border-none focus:outline-none flex-grow text-transparent selection:bg-accent/20 caret-transparent text-base font-medium pl-12 pr-10 py-3 w-full relative z-20"
        style={{ caretColor: "transparent" }}
        onFocus={() => setIsInputFocused(true)}
        onBlur={() => {
          setTimeout(() => {
            if (inputValue === "") {
              setIsInputFocused(false)
            }
          }, 100)
        }}
        value={inputValue}
        onChange={handleInputChange}
      />
      {!isInputFocused && !inputValue && (
        <div className="absolute left-12 top-1/2 transform -translate-y-1/2 pointer-events-none">
          {renderPlaceholder()}
        </div>
      )}
      <TypewriterEffect text={inputValue} />
      <AnimatePresence>
        {isInputFocused && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="text-accent absolute right-4 top-1/2 transform -translate-y-1/2 z-10"
            onClick={handleClearInput}
          >
            {inputValue ? <X size={20} /> : <Image size={20} />}
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  )
}

