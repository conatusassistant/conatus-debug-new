"use client"

import { useState, useEffect } from "react"
import { Search, Mic } from "lucide-react"
import { Button } from "@/components/ui/button"

const SUGGESTIONS = [
  "Need a ride? Schedule an Uber for tomorrow",
  "Low on coffee? Order your favorite blend",
  "Want to focus? Start a Pomodoro session",
  "Meeting prep? Gather documents for your 2PM",
]

export function ActionBar() {
  const [suggestion, setSuggestion] = useState(SUGGESTIONS[0])
  const [isTyping, setIsTyping] = useState(false)
  const [inputValue, setInputValue] = useState("")

  // Rotate suggestions when idle
  useEffect(() => {
    if (!isTyping) {
      const interval = setInterval(() => {
        setSuggestion(SUGGESTIONS[Math.floor(Math.random() * SUGGESTIONS.length)])
      }, 3000)

      return () => clearInterval(interval)
    }
  }, [isTyping])

  return (
    <div className="relative">
      <div className="flex items-center bg-zinc-800/50 backdrop-blur-sm border border-zinc-700 rounded-xl p-3 transition-all duration-300 focus-within:border-neon-blue focus-within:neon-glow">
        {isTyping ? (
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className="bg-transparent border-none outline-none flex-grow text-white placeholder-zinc-500"
            placeholder="Tell me what you need..."
            onBlur={() => {
              if (!inputValue) {
                setIsTyping(false)
              }
            }}
            autoFocus
          />
        ) : (
          <div
            className="flex-grow text-neon-blue cursor-text transition-all duration-300"
            onClick={() => setIsTyping(true)}
          >
            {suggestion}
          </div>
        )}

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8 text-neon-pink hover:bg-zinc-700">
            <Mic className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8 text-neon-blue hover:bg-zinc-700">
            <Search className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {isTyping && inputValue && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-zinc-800/90 backdrop-blur-sm border border-zinc-700 rounded-xl p-2 z-20 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="p-2 hover:bg-zinc-700 rounded-lg cursor-pointer transition-colors">
            <p className="text-white">{inputValue}</p>
            <p className="text-xs text-zinc-400">Press Enter to create automation</p>
          </div>
        </div>
      )}
    </div>
  )
}

