import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function DealsCard() {
  return (
    <Card className="rounded-xl shadow-sm">
      <CardHeader>
        <CardTitle>Deals</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold">1,234</div>
        <div className="flex items-center mt-2">
          <Badge variant="secondary" className="mr-2">
            +12%
          </Badge>
          <span className="text-sm text-gray-500">vs last week</span>
        </div>
      </CardContent>
    </Card>
  )
}

