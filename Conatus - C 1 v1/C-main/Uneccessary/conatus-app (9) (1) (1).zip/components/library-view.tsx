"use client"

import { useState, useEffect, useRef } from "react"
import React from "react"
import { motion, AnimatePresence } from "framer-motion"
import { RefreshCw, Download, Star, Plus, Settings, X, Search } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"

const POPULAR_APPS = [
  { name: "Perplexity", icon: "🧠" },
  { name: "Claude", icon: "🤖" },
  { name: "Uber", icon: "🚗" },
  { name: "DoorDash", icon: "🍔" },
  { name: "Google Calendar", icon: "📅" },
  { name: "Airtable", icon: "📊" },
  { name: "Spotify", icon: "🎵" },
  { name: "Gmail", icon: "📧" },
  { name: "Slack", icon: "💬" },
  { name: "Zoom", icon: "🎥" },
  { name: "Trello", icon: "📋" },
  { name: "Notion", icon: "📝" },
  { name: "Dropbox", icon: "📁" },
  { name: "Twitter", icon: "🐦" },
  { name: "Instagram", icon: "📷" },
  { name: "LinkedIn", icon: "💼" },
  { name: "GitHub", icon: "🐙" },
  { name: "Asana", icon: "✅" },
  { name: "Evernote", icon: "🐘" },
  { name: "Zapier", icon: "⚡" },
]

const AUTOMATIONS = [
  {
    id: "1",
    name: "Morning Routine",
    description: "Start your day right with personalized updates",
    logo: "🌅",
    details: "This automation sends a daily briefing with weather, top news, and your schedule for the day.",
    lastRun: "Today at 7:00 AM",
  },
  {
    id: "2",
    name: "Expense Tracker",
    description: "Automatically categorize and log expenses",
    logo: "💰",
    details: "Syncs with your bank account to categorize transactions and update your budget spreadsheet.",
    lastRun: "Yesterday at 11:30 PM",
  },
  {
    id: "3",
    name: "Social Media Manager",
    description: "Schedule and post content across platforms",
    logo: "📱",
    details: "Allows you to schedule posts for multiple social media platforms from a single interface.",
    lastRun: "2 hours ago",
  },
  {
    id: "4",
    name: "Fitness Goal Tracker",
    description: "Monitor your workouts and nutrition",
    logo: "💪",
    details: "Integrates with fitness apps to track your progress and send motivational reminders.",
    lastRun: "3 days ago",
  },
  {
    id: "5",
    name: "Smart Home Controller",
    description: "Automate your home based on your routines",
    logo: "🏠",
    details: "Controls your smart home devices based on your location, time of day, and preferences.",
    lastRun: "1 hour ago",
  },
]

// First, update the COMMUNITY_AUTOMATIONS array to include reviews data
const COMMUNITY_AUTOMATIONS = [
  {
    id: "1",
    name: "AI-Powered Email Assistant",
    description: "Let AI handle your email correspondence",
    logo: "🤖",
    downloads: 15234,
    rating: 4.8,
    reviews: [
      {
        user: "Sarah K.",
        rating: 5,
        comment: "This has saved me hours every week! The AI is surprisingly good at understanding context.",
      },
      { user: "Michael T.", rating: 5, comment: "Excellent tool. It handles my customer service emails perfectly." },
      { user: "Jamie L.", rating: 4, comment: "Very good, but occasionally needs correction on complex topics." },
    ],
  },
  {
    id: "2",
    name: "Automated Meal Planner",
    description: "Generate weekly meal plans and shopping lists",
    logo: "🍽️",
    downloads: 8976,
    rating: 4.6,
    reviews: [
      { user: "Chris P.", rating: 5, comment: "Love how it considers my dietary restrictions and preferences!" },
      {
        user: "Taylor M.",
        rating: 4,
        comment: "Great for meal prep, though I wish it had more international cuisine options.",
      },
      { user: "Alex W.", rating: 5, comment: "The shopping list feature alone is worth it. Saves so much time." },
    ],
  },
  {
    id: "3",
    name: "Personal Finance Advisor",
    description: "Get AI-driven insights on your spending habits",
    logo: "📊",
    downloads: 12543,
    rating: 4.7,
    reviews: [
      { user: "Jordan B.", rating: 5, comment: "Helped me identify unnecessary subscriptions I was paying for!" },
      {
        user: "Morgan R.",
        rating: 4,
        comment: "Great insights, though the categorization sometimes needs manual correction.",
      },
      { user: "Casey T.", rating: 5, comment: "The monthly reports are incredibly detailed and helpful." },
    ],
  },
  {
    id: "4",
    name: "Language Learning Assistant",
    description: "Daily language exercises tailored to your level",
    logo: "🗣️",
    downloads: 9876,
    rating: 4.5,
    reviews: [
      { user: "Robin S.", rating: 5, comment: "I've made more progress in Spanish with this than years of classes." },
      { user: "Avery P.", rating: 4, comment: "The daily exercises are perfect for consistent practice." },
      {
        user: "Quinn L.",
        comment: "Great for vocabulary building, though pronunciation feedback could be improved.",
      },
    ],
  },
  {
    id: "5",
    name: "Productivity Booster",
    description: "Optimize your work habits with smart reminders",
    logo: "⏱️",
    downloads: 14321,
    rating: 4.9,
    reviews: [
      { user: "Riley J.", rating: 5, comment: "The focus timer and break reminders have transformed my workday." },
      { user: "Dakota F.", rating: 5, comment: "I love how it learns my productivity patterns over time." },
      { user: "Skyler M.", rating: 5, comment: "The distraction blocking feature is a game changer for me." },
    ],
  },
]

// Update the CONNECTED_APPS array to include more detailed information
const CONNECTED_APPS = [
  {
    name: "Slack",
    icon: "💬",
    status: "Connected",
    lastSync: "5 minutes ago",
    apiKey: "sk_live_*****************8F3D",
    permissions: ["Read messages", "Send messages", "Create channels"],
    usage: { daily: 142, monthly: 3240, limit: 5000 },
    actions: ["Send Message", "Create Channel", "Update Status"],
    webhooks: ["New message", "Channel created"],
  },
  {
    name: "Google Drive",
    icon: "📁",
    status: "Connected",
    lastSync: "1 hour ago",
    apiKey: "AIza*****************hUk",
    permissions: ["Read files", "Write files", "Share files"],
    usage: { daily: 37, monthly: 856, limit: 10000 },
    actions: ["Upload File", "Create Folder", "Share Document"],
    webhooks: ["File updated", "New comment"],
  },
  {
    name: "Trello",
    icon: "📌",
    status: "Disconnected",
    lastSync: "Never",
    apiKey: "",
    permissions: [],
    usage: { daily: 0, monthly: 0, limit: 1000 },
    actions: ["Create Card", "Move Card", "Add Comment"],
    webhooks: ["Card created", "Card moved"],
  },
]

export function LibraryView() {
  // Update the state variables at the top of the LibraryView component function
  const [activeTab, setActiveTab] = useState("For You")
  const [expandedId, setExpandedId] = useState(null)
  const [showAppList, setShowAppList] = useState(false)
  const [currentApp, setCurrentApp] = useState(POPULAR_APPS[0])
  const [searchQuery, setSearchQuery] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [newAutomationName, setNewAutomationName] = useState("")
  const [newAutomationDescription, setNewAutomationDescription] = useState("")
  const [selectedIcon, setSelectedIcon] = useState("🌅")
  const [appSearchQuery, setAppSearchQuery] = useState("")
  const [selectedApps, setSelectedApps] = useState([])
  const [currentStep, setCurrentStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const modalRef = useRef(null)

  // Add these state variables after the existing state declarations in the LibraryView component
  const [connectedAppStatuses, setConnectedAppStatuses] = useState(
    CONNECTED_APPS.reduce((acc, app) => {
      acc[app.name] = app.status === "Connected"
      return acc
    }, {}),
  )
  const [automationEnabled, setAutomationEnabled] = useState(
    AUTOMATIONS.reduce((acc, automation) => {
      acc[automation.id] = true
      return acc
    }, {}),
  )
  const [installingId, setInstallingId] = useState(null)
  const [installedAutomations, setInstalledAutomations] = useState([])

  // Add this to the existing state variables after the installedAutomations state
  const [forYouAutomations, setForYouAutomations] = useState([...AUTOMATIONS])

  // Add new state variables at the top of the component:
  const [triggerType, setTriggerType] = useState("event")
  const [appConfigs, setAppConfigs] = useState({})

  useEffect(() => {
    if (!isTyping) {
      const interval = setInterval(() => {
        setCurrentApp(POPULAR_APPS[Math.floor(Math.random() * POPULAR_APPS.length)])
      }, 3000)

      return () => clearInterval(interval)
    }
  }, [isTyping])

  useEffect(() => {
    // Close modal when clicking outside
    function handleClickOutside(event) {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setShowCreateModal(false)
      }
    }

    if (showCreateModal) {
      document.addEventListener("mousedown", handleClickOutside)
    } else {
      document.removeEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [showCreateModal])

  const handleSearch = (e) => {
    setSearchQuery(e.target.value)
    // Implement search functionality here
  }

  // Add this function to handle app selection
  const handleAppSelection = (app) => {
    if (selectedApps.some((a) => a.name === app.name)) {
      setSelectedApps(selectedApps.filter((a) => a.name !== app.name))
    } else {
      setSelectedApps([...selectedApps, app])
    }
  }

  // Add this function to handle automation creation - FIXED
  const handleCreateAutomation = async () => {
    setIsLoading(true)

    try {
      // Create the automation object
      const newAutomation = {
        name: newAutomationName,
        description: newAutomationDescription,
        icon: selectedIcon,
        triggerType,
        config: {
          apps: selectedApps.map((app) => app.name),
          appConfigs,
        },
        isEnabled: true,
      }

      // Generate a unique ID for the automation (client-side fallback)
      const clientId = `local-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`

      try {
        // Try to call the API first
        const response = await fetch("/api/automations", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(newAutomation),
        })

        if (!response.ok) {
          throw new Error(`Server responded with ${response.status}: ${response.statusText}`)
        }

        const data = await response.json()

        // Add to forYouAutomations with server-generated ID
        const uiAutomation = {
          id: data.automation.id,
          name: data.automation.name,
          description: data.automation.description,
          logo: data.automation.icon,
          apps: selectedApps,
          triggerType: data.automation.triggerType,
          details: `Custom automation with ${selectedApps.length} connected apps`,
          lastRun: "Never",
          isNew: true,
        }

        setForYouAutomations((prev) => [...prev, uiAutomation])
        console.log("Automation created successfully via API")
      } catch (apiError) {
        console.error("API Error:", apiError)

        // Fallback: Create the automation locally if the API fails
        const localAutomation = {
          id: clientId,
          name: newAutomationName,
          description: newAutomationDescription,
          logo: selectedIcon,
          apps: selectedApps,
          triggerType: triggerType,
          details: `Custom automation with ${selectedApps.length} connected apps`,
          lastRun: "Never",
          isNew: true,
        }

        setForYouAutomations((prev) => [...prev, localAutomation])
        console.log("Automation created locally as fallback")
      }

      // Reset form and close modal
      setShowCreateModal(false)
      setNewAutomationName("")
      setNewAutomationDescription("")
      setSelectedApps([])
      setCurrentStep(1)
      setAppSearchQuery("")
      setTriggerType("event")
      setAppConfigs({})

      // Switch to For You tab to show the new automation
      setActiveTab("For You")
    } catch (error) {
      console.error("Error creating automation:", error)
      // Show error toast or notification
      alert("Failed to create automation. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  // Add this function to handle app connection toggle
  const handleAppConnectionToggle = (appName) => {
    setConnectedAppStatuses({
      ...connectedAppStatuses,
      [appName]: !connectedAppStatuses[appName],
    })
  }

  // Add this function to handle automation toggle
  const handleAutomationToggle = (automationId) => {
    setAutomationEnabled({
      ...automationEnabled,
      [automationId]: !automationEnabled[automationId],
    })
  }

  // Update the handleInstallAutomation function to add the installed automation to the For You list - FIXED
  const handleInstallAutomation = (automation) => {
    // Set the installing state to show loading
    setInstallingId(automation.id)

    // Simulate installation process
    setTimeout(() => {
      try {
        // Add to installed automations
        setInstalledAutomations((prev) => [...prev, automation.id])

        // Add the automation to the For You list
        const newAutomation = {
          id: `community-${automation.id}`,
          name: automation.name,
          description: automation.description,
          logo: automation.logo,
          details: `Installed from Community. ${automation.reviews.length} users rated this ${automation.rating}/5`,
          lastRun: "Not run yet",
          isNew: true, // Add this flag for new automations
        }

        setForYouAutomations((prev) => [...prev, newAutomation])
        console.log(`Automation "${automation.name}" installed successfully`)

        // Auto-switch to For You tab to show the newly installed automation
        setActiveTab("For You")
      } catch (error) {
        console.error("Error installing automation:", error)
        alert(`Failed to install "${automation.name}". Please try again.`)
      } finally {
        // Clear installing state
        setInstallingId(null)
      }
    }, 1500)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F1EA] via-[#EBE5D8] to-[#E1D8C8]">
      <div className="max-w-4xl mx-auto p-3 pt-1 space-y-3">
        {/* Header Section */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[#2D3436] leading-tight">Library</h1>
            <p className="text-xs text-[#2D3436]/70">Connect apps, create workflows, explore presets</p>
          </div>
        </div>

        {/* Shuffle Deck and Add Apps Section */}
        <div className="bg-white/30 backdrop-blur-sm rounded-lg p-2 shadow-sm">
          <div className="flex items-center gap-2">
            <div className="flex-grow relative">
              <input
                type="text"
                placeholder={`Add ${currentApp.name} ${currentApp.icon}`}
                value={searchQuery}
                onChange={handleSearch}
                className="w-full bg-transparent rounded-lg py-2 pl-4 pr-3 text-sm text-[#2D3436] placeholder-[#2D3436]/50 focus:outline-none"
              />
            </div>
            <button
              onClick={() => setShowAppList(!showAppList)}
              className="bg-[#3A7B7F] text-white p-2 rounded-lg text-sm font-medium hover:bg-[#3A7B7F]/90 transition-colors flex items-center justify-center"
            >
              <Plus size={20} />
            </button>
          </div>

          {/* App List */}
          <AnimatePresence>
            {showAppList && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="mt-2 grid grid-cols-4 gap-2"
              >
                {POPULAR_APPS.map((app) => (
                  <button
                    key={app.name}
                    className="flex flex-col items-center justify-center p-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors"
                  >
                    <span className="text-2xl mb-1">{app.icon}</span>
                    <span className="text-xs text-[#2D3436] text-center">{app.name}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Tab Navigation - Updated to match social page style */}
        <div className="flex space-x-1 overflow-x-auto">
          {["Settings", "For You", "Community"].map((tab) => (
            <Button
              key={tab}
              variant={activeTab === tab ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab(tab)}
              className={`whitespace-nowrap text-xs py-1 h-7 ${
                activeTab === tab
                  ? "bg-[#3A7B7F] text-white"
                  : "bg-[#ECE2D0] text-[#2F2F2F] hover:bg-[#3A7B7F] hover:text-white"
              }`}
            >
              {tab}
            </Button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="space-y-2 mt-1">
          {/* Settings Tab Content */}
          {activeTab === "Settings" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-lg font-semibold text-[#2D3436]">Connected Apps</h2>
              </div>
              {CONNECTED_APPS.map((app) => (
                <motion.div
                  key={app.name}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <motion.div
                    className="bg-white/20 rounded-lg p-4 hover:bg-white/30 transition-all shadow-sm"
                    whileHover={{ scale: 1.01 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-lg bg-[#3A7B7F]/10 flex items-center justify-center text-xl">
                          {app.icon}
                        </div>
                        <div>
                          <h3 className="font-semibold text-[#2D3436]">{app.name}</h3>
                          <p className="text-xs text-[#2D3436]/70">
                            {app.status === "Connected" ? `Last synced: ${app.lastSync}` : "Disconnected"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={connectedAppStatuses[app.name]}
                          onCheckedChange={() => handleAppConnectionToggle(app.name)}
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="rounded-full text-[#3A7B7F] hover:bg-[#3A7B7F]/10"
                          onClick={() => setExpandedId(expandedId === app.name ? null : app.name)}
                        >
                          <Settings size={18} />
                        </Button>
                      </div>
                    </div>

                    <AnimatePresence>
                      {expandedId === app.name && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="mt-3 pt-3 border-t border-[#3A7B7F]/10"
                        >
                          {connectedAppStatuses[app.name] ? (
                            <>
                              <div className="mb-4">
                                <h4 className="text-sm font-medium text-[#2D3436] mb-2">API Key</h4>
                                <div className="flex items-center gap-2">
                                  <code className="bg-white/20 px-2 py-1 rounded text-xs flex-grow">{app.apiKey}</code>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="text-xs"
                                    onClick={() => {
                                      // Copy to clipboard functionality
                                      navigator.clipboard.writeText(app.apiKey.replace("*", ""))
                                    }}
                                  >
                                    Copy
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="text-xs"
                                    onClick={() => {
                                      // Regenerate API key functionality
                                    }}
                                  >
                                    Regenerate
                                  </Button>
                                </div>
                              </div>

                              <div className="mb-4">
                                <h4 className="text-sm font-medium text-[#2D3436] mb-2">Permissions</h4>
                                <div className="grid grid-cols-2 gap-2">
                                  {app.permissions.map((permission) => (
                                    <div key={permission} className="flex items-center gap-2">
                                      <Switch id={`${app.name}-${permission}`} defaultChecked />
                                      <label
                                        htmlFor={`${app.name}-${permission}`}
                                        className="text-xs text-[#2D3436]/70"
                                      >
                                        {permission}
                                      </label>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              <div className="mb-4">
                                <h4 className="text-sm font-medium text-[#2D3436] mb-2">Usage</h4>
                                <div className="bg-white/10 rounded-lg p-2">
                                  <div className="flex justify-between text-xs text-[#2D3436]/70 mb-1">
                                    <span>Monthly API calls: {app.usage.monthly}</span>
                                    <span>{Math.round((app.usage.monthly / app.usage.limit) * 100)}% of limit</span>
                                  </div>
                                  <div className="w-full bg-white/20 rounded-full h-2">
                                    <div
                                      className="bg-[#3A7B7F] h-2 rounded-full"
                                      style={{ width: `${(app.usage.monthly / app.usage.limit) * 100}%` }}
                                    ></div>
                                  </div>
                                </div>
                              </div>

                              <div className="mb-4">
                                <h4 className="text-sm font-medium text-[#2D3436] mb-2">Quick Actions</h4>
                                <div className="flex flex-wrap gap-2">
                                  {app.actions.map((action) => (
                                    <Button
                                      key={action}
                                      variant="outline"
                                      size="sm"
                                      className="text-xs"
                                      onClick={() => {
                                        // Handle action
                                      }}
                                    >
                                      {action}
                                    </Button>
                                  ))}
                                </div>
                              </div>

                              <div className="mb-4">
                                <h4 className="text-sm font-medium text-[#2D3436] mb-2">Webhooks</h4>
                                <div className="grid grid-cols-2 gap-2">
                                  {app.webhooks.map((webhook) => (
                                    <div key={webhook} className="flex items-center gap-2">
                                      <Switch id={`${app.name}-${webhook}`} defaultChecked />
                                      <label htmlFor={`${app.name}-${webhook}`} className="text-xs text-[#2D3436]/70">
                                        {webhook}
                                      </label>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              <div className="flex justify-between">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-[#3A7B7F] border-[#3A7B7F]/30 hover:bg-[#3A7B7F]/10"
                                  onClick={() => {
                                    // Test connection functionality
                                  }}
                                >
                                  Test Connection
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-red-500 border-red-500/30 hover:bg-red-500/10"
                                  onClick={() => {
                                    // Disconnect app functionality
                                    handleAppConnectionToggle(app.name)
                                  }}
                                >
                                  Disconnect
                                </Button>
                              </div>
                            </>
                          ) : (
                            <div className="flex flex-col items-center justify-center py-4">
                              <p className="text-sm text-[#2D3436]/70 mb-3">
                                Connect your {app.name} account to enable automations
                              </p>
                              <Button
                                className="bg-[#3A7B7F] text-white hover:bg-[#3A7B7F]/90"
                                onClick={() => {
                                  // Connect app functionality
                                  handleAppConnectionToggle(app.name)
                                }}
                              >
                                Connect {app.name}
                              </Button>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                </motion.div>
              ))}
            </div>
          )}

          {/* For You Tab Content */}
          {activeTab === "For You" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold text-[#2D3436]">Your Automations</h2>
                <Button
                  className="px-3 py-1 rounded-md text-sm font-medium bg-[#3A7B7F] text-white hover:bg-[#3A7B7F]/90 transition-all shadow-sm"
                  onClick={() => setShowCreateModal(true)}
                >
                  <Plus size={16} className="mr-1" />
                  Create
                </Button>
              </div>

              {forYouAutomations.length === 0 ? (
                <div className="bg-white/20 rounded-lg p-8 text-center">
                  <div className="h-16 w-16 rounded-full bg-[#3A7B7F]/10 flex items-center justify-center text-2xl mx-auto mb-4">
                    🔍
                  </div>
                  <h3 className="font-semibold text-[#2D3436] mb-2">No automations yet</h3>
                  <p className="text-sm text-[#2D3436]/70 mb-4">
                    Create your first automation or install one from the Community tab
                  </p>
                  <div className="flex justify-center gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-[#3A7B7F] border-[#3A7B7F]/30 hover:bg-[#3A7B7F]/10"
                      onClick={() => setActiveTab("Community")}
                    >
                      Browse Community
                    </Button>
                    <Button
                      size="sm"
                      className="bg-[#3A7B7F] text-white hover:bg-[#3A7B7F]/90"
                      onClick={() => setShowCreateModal(true)}
                    >
                      Create Automation
                    </Button>
                  </div>
                </div>
              ) : (
                forYouAutomations.map((automation) => (
                  <motion.div
                    key={automation.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <motion.div
                      className={`bg-white/20 rounded-lg p-4 hover:bg-white/30 transition-all cursor-pointer shadow-sm ${automation.isNew ? "ring-2 ring-[#3A7B7F]/30" : ""}`}
                      onClick={() => setExpandedId(expandedId === automation.id ? null : automation.id)}
                      whileHover={{ scale: 1.01 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-lg bg-[#3A7B7F]/10 flex items-center justify-center text-xl">
                          {automation.logo}
                        </div>
                        <div className="flex-grow">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-[#2D3436]">{automation.name}</h3>
                            {automation.isNew && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-[#3A7B7F] text-white font-medium">
                                NEW
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-[#2D3436]/70">{automation.description}</p>
                          {automation.id.startsWith("community-") && (
                            <span className="inline-flex items-center mt-1 px-2 py-0.5 rounded-full text-xs bg-[#3A7B7F]/10 text-[#3A7B7F] font-medium">
                              <Download size={10} className="mr-1" />
                              From Community
                            </span>
                          )}
                        </div>
                        <Switch
                          checked={automationEnabled[automation.id] !== false}
                          onCheckedChange={() => handleAutomationToggle(automation.id)}
                        />
                      </div>

                      <AnimatePresence>
                        {expandedId === automation.id && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.3 }}
                            className="mt-3 pt-3 border-t border-[#3A7B7F]/10"
                          >
                            <p className="text-sm text-[#2D3436] mb-3">{automation.details}</p>
                            <div className="flex items-center justify-between">
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-[#3A7B7F] border-[#3A7B7F]/30 hover:bg-[#3A7B7F]/10"
                              >
                                <RefreshCw size={14} className="mr-2" />
                                Run Now
                              </Button>
                              <span className="text-xs text-[#2D3436]/50">Last run: {automation.lastRun}</span>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  </motion.div>
                ))
              )}
            </div>
          )}

          {/* Community Tab Content */}
          {activeTab === "Community" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-lg font-semibold text-[#2D3436]">Community Automations</h2>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search automations..."
                      className="w-full bg-white/20 rounded-lg py-1.5 pl-8 pr-3 text-sm text-[#2D3436] placeholder-[#2D3436]/50 focus:outline-none focus:ring-1 focus:ring-[#3A7B7F]"
                    />
                    <Search
                      className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-[#2D3436]/50"
                      size={14}
                    />
                  </div>
                  <select className="bg-white/20 rounded-lg py-1.5 px-3 text-sm text-[#2D3436] focus:outline-none focus:ring-1 focus:ring-[#3A7B7F]">
                    <option value="popular">Most Popular</option>
                    <option value="recent">Recently Added</option>
                    <option value="rating">Highest Rated</option>
                  </select>
                </div>
              </div>

              <div className="flex overflow-x-auto pb-2 gap-2 mb-4">
                {["All", "Productivity", "Social Media", "Finance", "Health", "Home", "Travel"].map((category) => (
                  <Button
                    key={category}
                    variant="outline"
                    size="sm"
                    className={`whitespace-nowrap ${category === "All" ? "bg-[#3A7B7F] text-white" : "bg-white/20 text-[#2D3436]"}`}
                  >
                    {category}
                  </Button>
                ))}
              </div>

              {COMMUNITY_AUTOMATIONS.map((automation) => (
                <motion.div
                  key={automation.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <motion.div
                    className="bg-white/20 rounded-lg p-4 hover:bg-white/30 transition-all shadow-sm"
                    whileHover={{ scale: 1.01 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-lg bg-[#3A7B7F]/10 flex items-center justify-center text-xl">
                        {automation.logo}
                      </div>
                      <div className="flex-grow">
                        <h3 className="font-semibold text-[#2D3436]">{automation.name}</h3>
                        <p className="text-xs text-[#2D3436]/70 mb-1">{automation.description}</p>
                        <div className="flex items-center gap-3 text-xs text-[#2D3436]/50">
                          <span className="flex items-center">
                            <Download size={12} className="mr-1" />
                            {automation.downloads.toLocaleString()}
                          </span>
                          <button
                            className="flex items-center cursor-pointer group"
                            onClick={() => setExpandedId(expandedId === automation.id ? null : automation.id)}
                          >
                            <span className="flex items-center">
                              <Star size={12} className="text-yellow-500 fill-current mr-1" />
                              {automation.rating}
                            </span>
                            <svg
                              width="12"
                              height="12"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              className={`ml-1 transition-transform duration-200 ${expandedId === automation.id ? "rotate-180" : ""}`}
                            >
                              <path d="M6 9l6 6 6-6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                          </button>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className={`${
                          installingId === automation.id
                            ? "bg-gray-400"
                            : installedAutomations.includes(automation.id)
                              ? "bg-green-600 hover:bg-green-700"
                              : "bg-[#3A7B7F] hover:bg-[#3A7B7F]/90"
                        } text-white transition-all`}
                        onClick={() => handleInstallAutomation(automation)}
                        disabled={installingId === automation.id || installedAutomations.includes(automation.id)}
                      >
                        {installingId === automation.id ? (
                          <div className="flex items-center">
                            <svg
                              className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                            >
                              <circle
                                className="opacity-25"
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="currentColor"
                                strokeWidth="4"
                              ></circle>
                              <path
                                className="opacity-75"
                                fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                              ></path>
                            </svg>
                            Installing...
                          </div>
                        ) : installedAutomations.includes(automation.id) ? (
                          <div className="flex items-center">
                            <svg
                              className="w-4 h-4 mr-2"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth="2"
                                d="M5 13l4 4L19 7"
                              ></path>
                            </svg>
                            Installed
                          </div>
                        ) : (
                          <>
                            <Download size={14} className="mr-2" />
                            Install
                          </>
                        )}
                      </Button>
                    </div>

                    <AnimatePresence>
                      {expandedId === automation.id && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="mt-3 pt-3 border-t border-[#3A7B7F]/10"
                        >
                          <h4 className="text-sm font-medium text-[#2D3436] mb-2">Top Reviews</h4>
                          <div className="space-y-3">
                            {automation.reviews.map((review, index) => (
                              <div key={index} className="bg-white/10 rounded-lg p-3">
                                <div className="flex justify-between items-center mb-1">
                                  <span className="font-medium text-sm text-[#2D3436]">{review.user}</span>
                                  <div className="flex">
                                    {[...Array(5)].map((_, i) => (
                                      <Star
                                        key={i}
                                        size={12}
                                        className={i < review.rating ? "text-yellow-500 fill-current" : "text-gray-300"}
                                      />
                                    ))}
                                  </div>
                                </div>
                                <p className="text-xs text-[#2D3436]/80">{review.comment}</p>
                              </div>
                            ))}
                          </div>
                          <div className="flex justify-center mt-3">
                            <Button variant="ghost" size="sm" className="text-xs text-[#3A7B7F]">
                              View All Reviews
                            </Button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Create Automation Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
          >
            <motion.div
              ref={modalRef}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
              className="bg-white rounded-xl p-6 w-full max-w-2xl shadow-xl max-h-[80vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-[#2D3436]">Create New Automation</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full h-8 w-8"
                  onClick={() => setShowCreateModal(false)}
                >
                  <X size={18} />
                </Button>
              </div>

              {/* Step indicator */}
              <div className="flex items-center mb-6">
                <div
                  className={`h-8 w-8 rounded-full flex items-center justify-center ${currentStep === 1 ? "bg-[#3A7B7F] text-white" : "bg-[#3A7B7F]/20 text-[#3A7B7F]"}`}
                >
                  1
                </div>
                <div className={`h-1 w-12 ${currentStep > 1 ? "bg-[#3A7B7F]" : "bg-[#3A7B7F]/20"}`}></div>
                <div
                  className={`h-8 w-8 rounded-full flex items-center justify-center ${currentStep === 2 ? "bg-[#3A7B7F] text-white" : "bg-[#3A7B7F]/20 text-[#3A7B7F]"}`}
                >
                  2
                </div>
                <div className={`h-1 w-12 ${currentStep > 2 ? "bg-[#3A7B7F]" : "bg-[#3A7B7F]/20"}`}></div>
                <div
                  className={`h-8 w-8 rounded-full flex items-center justify-center ${currentStep === 3 ? "bg-[#3A7B7F] text-white" : "bg-[#3A7B7F]/20 text-[#3A7B7F]"}`}
                >
                  3
                </div>
              </div>

              {/* Step 1: Basic Info */}
              {currentStep === 1 && (
                <div className="space-y-4">
                  <div>
                    <label htmlFor="automation-name" className="block text-sm font-medium text-[#2D3436] mb-1">
                      Automation Name
                    </label>
                    <input
                      id="automation-name"
                      type="text"
                      value={newAutomationName}
                      onChange={(e) => setNewAutomationName(e.target.value)}
                      placeholder="Morning Routine"
                      className="w-full p-2 rounded-lg border border-[#3A7B7F]/20 focus:border-[#3A7B7F] focus:ring-1 focus:ring-[#3A7B7F] outline-none bg-white/80"
                    />
                  </div>

                  <div>
                    <label htmlFor="automation-description" className="block text-sm font-medium text-[#2D3436] mb-1">
                      Description
                    </label>
                    <textarea
                      id="automation-description"
                      value={newAutomationDescription}
                      onChange={(e) => setNewAutomationDescription(e.target.value)}
                      placeholder="Describe what this automation will do..."
                      rows={3}
                      className="w-full p-2 rounded-lg border border-[#3A7B7F]/20 focus:border-[#3A7B7F] focus:ring-1 focus:ring-[#3A7B7F] outline-none bg-white/80 resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#2D3436] mb-1">Choose Icon</label>
                    <div className="grid grid-cols-8 gap-2">
                      {[
                        "🌅",
                        "💰",
                        "📱",
                        "💪",
                        "🏠",
                        "🤖",
                        "📊",
                        "🗣️",
                        "⏱️",
                        "🍽️",
                        "📅",
                        "📧",
                        "🎵",
                        "🚗",
                        "🍔",
                        "💬",
                      ].map((icon) => (
                        <button
                          key={icon}
                          className={`h-10 w-10 rounded-lg ${selectedIcon === icon ? "bg-[#3A7B7F] text-white" : "bg-[#3A7B7F]/10 hover:bg-[#3A7B7F]/20"} flex items-center justify-center text-xl transition-colors`}
                          onClick={() => setSelectedIcon(icon)}
                        >
                          {icon}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Connect Apps */}
              {/* Update the Step 2: Connect Apps section with better styling and fixed navigation */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div>
                    <label className="block text-lg font-semibold text-[#2D3436] mb-2">Connect Apps</label>
                    <p className="text-sm text-[#2D3436]/70 mb-4">
                      Select the apps you want to connect in this automation
                    </p>

                    {/* Search bar for apps */}
                    <div className="relative mb-6">
                      <input
                        type="text"
                        value={appSearchQuery}
                        onChange={(e) => setAppSearchQuery(e.target.value)}
                        placeholder="Search for apps..."
                        className="w-full p-3 pl-11 rounded-xl border border-[#3A7B7F]/20 focus:border-[#3A7B7F] focus:ring-2 focus:ring-[#3A7B7F]/20 outline-none bg-white/80 text-[#2D3436]"
                      />
                      <Search
                        className="absolute left-4 top-1/2 transform -translate-y-1/2 text-[#3A7B7F]/50"
                        size={18}
                      />
                    </div>

                    {/* Selected apps */}
                    {selectedApps.length > 0 && (
                      <div className="mb-6 bg-[#3A7B7F]/5 p-4 rounded-xl border border-[#3A7B7F]/10">
                        <label className="block text-sm font-medium text-[#2D3436] mb-3">Selected Apps</label>
                        <div className="flex flex-wrap gap-2">
                          {selectedApps.map((app) => (
                            <div
                              key={app.name}
                              className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg border border-[#3A7B7F]/20 shadow-sm"
                            >
                              <span className="text-xl">{app.icon}</span>
                              <span className="text-sm font-medium text-[#2D3436]">{app.name}</span>
                              <button
                                className="ml-2 text-[#3A7B7F]/70 hover:text-[#3A7B7F] transition-colors"
                                onClick={() => handleAppSelection(app)}
                              >
                                <X size={16} />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* App grid with improved layout */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[400px] overflow-y-auto pr-2">
                      {POPULAR_APPS.filter((app) => app.name.toLowerCase().includes(appSearchQuery.toLowerCase())).map(
                        (app) => (
                          <button
                            key={app.name}
                            className={`flex flex-col items-center justify-center p-4 rounded-xl transition-all ${
                              selectedApps.some((a) => a.name === app.name)
                                ? "bg-[#3A7B7F]/10 border-2 border-[#3A7B7F] shadow-md"
                                : "bg-white hover:bg-[#3A7B7F]/5 border border-[#3A7B7F]/10 hover:border-[#3A7B7F]/30"
                            }`}
                            onClick={() => handleAppSelection(app)}
                          >
                            <div
                              className={`text-3xl mb-3 transform transition-transform ${
                                selectedApps.some((a) => a.name === app.name) ? "scale-110" : ""
                              }`}
                            >
                              {app.icon}
                            </div>
                            <span className="text-sm font-medium text-center text-[#2D3436]">{app.name}</span>
                          </button>
                        ),
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Configure Workflow */}
              {currentStep === 3 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-[#2D3436] mb-1">Configure Workflow</label>
                    <p className="text-sm text-[#2D3436]/70 mb-3">Set up how your apps will work together</p>

                    {selectedApps.length > 0 ? (
                      <div className="space-y-4">
                        {/* Workflow visualization */}
                        <div className="bg-[#F5F1EA] p-4 rounded-lg">
                          <div className="flex flex-col items-center">
                            {selectedApps.map((app, index) => (
                              <React.Fragment key={app.name}>
                                <div className="flex items-center gap-3 bg-white p-3 rounded-lg shadow-sm w-full">
                                  <div className="h-10 w-10 rounded-lg bg-[#3A7B7F]/10 flex items-center justify-center text-xl">
                                    {app.icon}
                                  </div>
                                  <div>
                                    <h4 className="font-medium text-[#2D3436]">{app.name}</h4>
                                    <p className="text-xs text-[#2D3436]/70">{index === 0 ? "Trigger" : "Action"}</p>
                                  </div>
                                  <div className="ml-auto">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="text-xs"
                                      onClick={() => {
                                        // Add configuration logic here
                                        console.log(`Configuring ${app.name}`)
                                      }}
                                    >
                                      Configure
                                    </Button>
                                  </div>
                                </div>
                                {index < selectedApps.length - 1 && (
                                  <div className="h-8 border-l-2 border-dashed border-[#3A7B7F]/30"></div>
                                )}
                              </React.Fragment>
                            ))}
                          </div>
                        </div>

                        {/* Trigger conditions */}
                        <div className="bg-white p-4 rounded-lg border border-[#3A7B7F]/10">
                          <h4 className="font-medium text-[#2D3436] mb-2">When should this automation run?</h4>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                id="schedule"
                                name="trigger"
                                className="text-[#3A7B7F]"
                                onChange={() => setTriggerType("schedule")}
                                checked={triggerType === "schedule"}
                              />
                              <label htmlFor="schedule" className="text-sm">
                                On a schedule
                              </label>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                id="event"
                                name="trigger"
                                className="text-[#3A7B7F]"
                                onChange={() => setTriggerType("event")}
                                checked={triggerType === "event"}
                              />
                              <label htmlFor="event" className="text-sm">
                                When an event occurs
                              </label>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                id="manual"
                                name="trigger"
                                className="text-[#3A7B7F]"
                                onChange={() => setTriggerType("manual")}
                                checked={triggerType === "manual"}
                              />
                              <label htmlFor="manual" className="text-sm">
                                Manual trigger only
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 bg-[#F5F1EA]/50 rounded-lg">
                        <p className="text-[#2D3436]/70">Please select apps in the previous step</p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-2 text-[#3A7B7F] border-[#3A7B7F]/30"
                          onClick={() => setCurrentStep(2)}
                        >
                          Go Back
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Navigation buttons */}
              <div className="flex justify-between mt-6">
                <Button
                  variant="outline"
                  onClick={() => {
                    if (currentStep === 1) {
                      setShowCreateModal(false)
                    } else {
                      setCurrentStep(currentStep - 1)
                    }
                  }}
                  className="border-[#3A7B7F]/30 text-[#3A7B7F] hover:bg-[#3A7B7F]/10"
                >
                  {currentStep === 1 ? "Cancel" : "Back"}
                </Button>

                <Button
                  onClick={() => {
                    if (currentStep === 3) {
                      handleCreateAutomation()
                    } else {
                      setCurrentStep(currentStep + 1)
                    }
                  }}
                  className="bg-[#3A7B7F] text-white hover:bg-[#3A7B7F]/90"
                  disabled={
                    (currentStep === 1 && (!newAutomationName.trim() || !newAutomationDescription.trim())) ||
                    (currentStep === 2 && selectedApps.length === 0) ||
                    (currentStep === 3 && !triggerType) ||
                    isLoading
                  }
                  type="button"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                          fill="none"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        />
                      </svg>
                      Creating...
                    </div>
                  ) : currentStep === 3 ? (
                    "Create Automation"
                  ) : (
                    "Next"
                  )}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

