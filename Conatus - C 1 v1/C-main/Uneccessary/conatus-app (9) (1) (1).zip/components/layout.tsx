import type React from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { BottomNavigation } from "./bottom-navigation"
import { CentralLogoTagline } from "./central-logo-tagline"

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background pb-32 flex flex-col">
      <header className="flex justify-end p-4 bg-white shadow-sm">
        <Avatar>
          <AvatarImage src="/avatar.png" />
          <AvatarFallback>CN</AvatarFallback>
        </Avatar>
      </header>
      <main className="flex-grow flex items-center justify-center">
        <CentralLogoTagline />
      </main>
      <BottomNavigation />
    </div>
  )
}

