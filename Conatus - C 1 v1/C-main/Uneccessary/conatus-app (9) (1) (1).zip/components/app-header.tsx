"use client"

import { motion } from "framer-motion"
import { Menu } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import { UserMenu } from "@/components/user-menu"
import { Button } from "@/components/ui/button"
import { ConatusLogo } from "@/components/conatus-logo"

interface AppHeaderProps {
  onMenuClick?: () => void
  showLogo?: boolean
  title?: string
  subtitle?: string
}

export function AppHeader({ onMenuClick, showLogo = true, title = "conatus", subtitle }: AppHeaderProps) {
  return (
    <motion.header
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 500, damping: 25 }}
      className="flex items-center justify-between p-4 glass-card sticky top-0 z-40"
    >
      <div className="flex items-center gap-3">
        {onMenuClick && (
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-white/10 hover:bg-white/20 dark:bg-gray-800/10 dark:hover:bg-gray-800/20"
            onClick={onMenuClick}
          >
            <Menu className="h-5 w-5 text-accent" />
          </Button>
        )}

        {showLogo && <ConatusLogo className="h-6 w-6 text-accent" />}

        <div>
          <motion.h1
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 500 }}
            className="text-xl font-semibold text-foreground"
          >
            {title}
          </motion.h1>
          {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <ThemeToggle />
        <UserMenu />
      </div>
    </motion.header>
  )
}

